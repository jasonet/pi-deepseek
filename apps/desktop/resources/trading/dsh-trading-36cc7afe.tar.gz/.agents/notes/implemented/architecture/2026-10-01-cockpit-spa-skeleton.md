# 驾驶舱 SPA：独立构建产物 + 由 edge 托管（骨架）

日期：2026-10-01 · 阶段：P4 步骤 3（前端一半·骨架）· 卡片：bf92b5d2 · 包：`@dshtrading/cockpit`

## 事实

- **本仓第一个真正的前端工具链**：动工前实测，仓库里没有独立前端应用 —— 没有 `apps/`、根 package.json 里前端相关只有 vitest；出现 react 的地方全是 `packages/client-ui-*/package.json`，而那里 **react 18.2 是 peerDependency**（宿主提供），构建走 tsdown + `tsdown.client.config.mjs`。也就是说既有 `client-ui-*` 是"渲染在宿主 web 壳里的插件"，不是独立 SPA。卡片要求的独立 SPA 因此是新增形态，不是复用。
- **两个与三平面闭包有关的约束（本包的设计立场）**：① SPA **只进 GUI 平面的构建机**，运行时不带 React（bundle 自带）；② **bot 侧只通过 staticDir 指过来、不 import 本包** —— `plane:check` 要求 bot 闭包零 UI-heavy 依赖，P1 实测 bot 54 包 / GUI 195 包（差 141 包 47.2 MB）不能因为驾驶舱吃回去。
- **`base: '/v1/assets/'`**：构建产物里的资源路径直接指向 edge 的静态前缀，而不是站点根；带哈希资源可以被 edge 长缓存，`index.html` 不缓存（`serveStatic` 已按此实现并有测试）。
- **`chunkSizeWarningLimit: 300`** 作为首屏体积预算的第一道闸：超标即构建失败（不是"警告一下继续"）。
- **观测面不依赖 tick 流**（卡片硬要求）：骨架页只有一次卡片拉取 + 手动刷新，没有任何行情订阅；新鲜度用"数据取于 N 秒前"表达。
- **未知枚举的卡片渲染成不可操作态**：协议层已清空 actions，界面如实显示"此卡片需要升级客户端后才能操作"，不猜一个样子。

## 证据（真实输出）

    vite v7.3.6 building client environment for production...
    ✓ 26 modules transformed.
    dist/index.html                  0.34 kB │ gzip:  0.26 kB
    dist/assets/index-DQb-KEuK.js  144.38 kB │ gzip: 46.95 kB
    ✓ built in 239ms

首屏 gzip 46.95 kB（预算 300 kB 未触发）；产物经 `serveStatic` 验证：`index.html` 200 + `text/html` + `no-store`，引用资源 200 + `text/javascript` + `immutable`，`base` 前缀指向 `/v1/assets/` ✓。


## 五块信息架构（同日补，用 SSR 字符串断言验证）

`src/blocks.tsx` 把卡片渲染成四块：**Desk 首页 / 决策动态流 / 持仓与挂单 / 升级收件箱**（加上 `App.tsx` 的控制区共五块）。全部是**纯展示**（输入 `Card[]`、输出 DOM，无取数无副作用）—— 这样"渲染对不对"可以用 `react-dom/server` 的字符串断言直接钉住，**不需要 jsdom**。

落到可执行断言上的四条：

1. **不可操作卡片禁用全部动作**：`operable === false` ⇒ 不渲染任何 `<button>`、`data-operable="false"`、并给出"需要升级客户端"的说明；**但内容与 fallbackText 仍然显示**（用户能看到事实，只是不能操作）。
2. **持仓与挂单块里没有下单入口**（卡片硬要求"不做手动下单面板"）：断言不含买/卖/下单/submit/place 字样、不含 `<form>`。
3. **决策动态流按 revision 倒序**（新的在上），且只收 decision/trigger-trace/escalation —— 断言三段 indexOf 的先后关系，而不是"包含"。
4. **空态明说**（"没有待处理升级"之类）而不是渲染空白 —— 空白会让人以为界面坏了。

控制按钮（pause/resume/kill/flatten）在界面层**再拦一道二次确认**（协议层已要求控制类动作 confirm: true）：确认之后才发 POST /v1/commands，并带 clientRequestId（幂等键）。

测试 7 例（cockpit 包首个测试套件）：新鲜度三档 + 未取数；可操作/不可操作两种渲染；不可操作仍显示内容；首页不混入决策与持仓；动态流倒序且过滤；**持仓块无任何下单入口**；空态文案。


## 截图验证（ui-screenshot-verify）与它抓出的两个真问题

> 本节是 2026-10-01/02 当时按旧 skill 拍下的证据（临时回环服务 + 无头 Chrome 截图），保留原样；现行 UI 验证手法见 [2026-09-04 Note 的 2026-10-14 Decision](../process/2026-09-04-ui-verification-hosted-http-headless-chrome.md)——桌面壳 + Computer Use 窗口级点击/截图。

流程按 skill：临时服务（仅回环、跑完即杀）托管 dist + 夹具卡片 → curl 可达性 → headless Chrome 截图（--headless=new --timeout）→ **读图断言**（不是"跑完没报错"）。

    GET /            -> 200 text/html
    GET /v1/cards     -> 200 application/json（8 张夹具卡）
    GET asset        -> 200 text/javascript
    截图 1600x1200 / 112027 字节；读图确认：控制区四个按钮、Desk 两张卡（含"可用动作：知道了"）、
    决策动态 rev 12 → rev 11 倒序、升级卡、**未识别卡片块**（future-card + 兜底文本 + "需要升级客户端"、无按钮）

### 抓出的问题一：界面把"不认识的卡片"丢掉了

协议层做到了"未知枚举的卡片不可操作而**不是丢弃**"，但信息架构按 cardType 分块过滤时把它**在 UI 层丢了** —— 第一版截图里那张 future-card 完全不出现。于是"服务端说了有新东西、客户端装作没有"变成了事实上的静默丢弃：**协议的不丢弃保证必须在渲染层也成立才算数**。修法是新增"未识别卡片"块（任何不在契约 12 个已知类型里的卡片都露出来、强制 operable: false），放在页面**最前面**（需要升级客户端的提示不该埋在底部），并补两条测试（未知卡必须出现且无按钮；没有未知卡时整块不渲染）。

### 抓出的问题二：契约包引了 node:crypto

加上未知卡片块后 vite build 直接失败：

    error during build: ../contract/lib/ids.js (1:9): "randomUUID" is not exported by "__vite-browser-external"

根因：ids.ts 用 node:crypto 的 randomUUID 生成 id，而契约包要**同时被服务端、网页 SPA 与移动 App 引用**（卡片原文）—— 浏览器 bundle 里没有 node:crypto 这个模块。修法是改用 **Web Crypto**（globalThis.crypto.randomUUID）：Node >=19 与所有现代浏览器都有，这条依赖整个消失。**这个错误只有真构建浏览器产物时才会暴露** —— 契约包的 30 条单测（跑在 Node 里）全绿也发现不了。

修后：contract 30 例 ✓、cockpit 9 例 ✓、cockpit 构建 147.75 kB / gzip 48.22 kB ✓。


## 首屏加载实测（本地回环，2026-10-01）

    index.html  http=200  size=337B      ttfb=0.0035s  total=0.0036s
    engine js   http=200  size=147752B   ttfb=0.0013s  total=0.0014s
    gzip 后：index.html 269 字节 / engine js 48234 字节

**这份测量证明了什么、没证明什么**：证明了产物小、静态托管路径没有额外开销（TTFB 毫秒级）；**没有**证明"慢网首屏时间"—— 回环网络不构成任何真实网络证据，卡片要求的"首屏体积预算"目前只有构建期闸门（`chunkSizeWarningLimit: 300`）+ 体积数字，没有 RUM 或节流实测。

**顺手实测出的一个真缺口**：`serveStatic` **不做任何压缩** —— 上面的 147752 字节是**未压缩传输**，而同一份产物 gzip 后只有 48234 字节（约 1/3）。真实网络下（非回环）浏览器会多下 3 倍的字节，而这是纯服务端一行 `content-encoding` 协商就能拿回的收益。修法有两条，都还没做：① `serveStatic` 按 `accept-encoding` 协商返回 gzip（或 br）；② 构建期预压缩成 `.gz` 并让 `serveStatic` 优先发它（省 CPU，推荐）。**已修**（见下节）：预压缩 + 协商后，实际传输量回到 gzip 后的大小。


## 预压缩修复（同日补完，兑现上节的实测缺口）

两处改动：

1. **`serveStatic(relativePath, staticDir, acceptEncoding)`** 按 `accept-encoding` 协商：有 `.gz` 兄弟文件且客户端接受 gzip ⇒ 走**字节路径**（`bodyBytes`）+ `content-encoding: gzip` + `vary: accept-encoding`；没有预压缩产物 ⇒ 照常发明文（**绝不假装压缩过**），但 `vary` 仍在（缓存不该把两种表示混起来）；客户端不接受 gzip ⇒ 明文且无 `vary`。
2. **构建期预压缩**（`packages/cockpit/scripts/precompress.mjs`，接在 `vite build` 之后）：给 `.html/.js/.css/.svg/.json/.map` 生成 `.gz`；**压不动就不写**（避免出现比原文更大的 `.gz` 反而拖慢）。

为什么预压缩而不是每次请求临时压：省 CPU；产物与源码同源可控（压缩结果可审计）；`serveStatic` 只需协商取用，逻辑最薄。

**关键不变式仍然成立**：预压缩路径同样受目录遍历（403）与扩展名白名单（415）约束 —— 测试专门盯这一点（压缩不是绕过授权的口子）；`attachV1Surface` 在有 `bodyBytes` 时写字节，否则写字符串（把 gzip 写进 string 会破坏字节流）。

测试 4 例：gzip 协商回字节 + magic 1f8b + 解压回原文 + content-type 仍按原扩展名；无 `.gz` 时发明文但仍声明 vary；客户端不支持 gzip 时明文且无 vary；预压缩路径同样受遍历/白名单约束。


## 控制面不依赖数据面（卡片证据项，同日补）

卡片要求的一条证据是"**A0 端点在行情与 agent 全挂时仍可用**"。对驾驶舱这一侧，等价的命题是：**数据面（/v1/cards）失败时控制面（pause/resume/kill/flatten）仍然渲染且可用** —— 因为控制面与 A0 同源。

做法：把外壳抽成**纯组件** `CockpitShell`（数据与副作用留在 `App`），于是这个命题可以被断言，而不是靠"看代码觉得应该没事"。三条真实渲染断言：

1. 数据面报错（`error` 有值、`cards=[]`）时，四个控制按钮**照常渲染且未禁用**，同时错误可见；
2. 数据陈旧（10 分钟前）时，同时出现"数据已陈旧"与四个控制按钮；
3. 有命令在执行时，**四个按钮全部 disabled**（避免并发控制动作互相打架）。

控件顺序固定为 `pause → resume → kill → flatten`（先软后硬），并导出 `CONTROL_ACTIONS` 供测试与界面共用 —— 顺序与集合是一个家，不是两处各写一遍。


## brotli 支持（同日补完）

`serveStatic` 的协商改成**编码候选列表**：客户端接受 `br` 且存在 `.br` 产物 ⇒ 发 br；否则试 `gzip`；都没有 ⇒ 发明文（**绝不假装压缩过**）。候选列表这个形状的好处是"再加一种编码"只是往列表里推一项，而不是再叠一层 `if`。

构建期预压缩同时产出 `.gz` 与 `.br`（brotli 质量 11）。

测试补 2 例：同时接受 br 与 gzip 且有两者产物 ⇒ 发 br（字节按 `Buffer.equals` 比较 —— `toEqual` 会因 Buffer/Uint8Array 原型不同而假红，这条也是测试自己抓出来的）；只接受 gzip ⇒ 回落 gzip；只接受 br 但没有 `.br` 产物 ⇒ 发明文且仍声明 `vary`。

**仍未验证**：br 相对 gzip 的**实际收益**没有量出来（本轮只证明了协商与回落正确）—— 下一轮可以在构建输出里直接比对两个产物的字节数。


## A0 端到端验证（卡片证据项，同日补完）

卡片要求的证据是"**A0 端点在行情与 agent 全挂时仍可用**"。此前只有渲染层断言（控制面不受数据面失败影响）与 P2 的 edge 单测；这一轮补上了**真实 edge 上的端到端记录**：

    # packages/cockpit/drill/a0-e2e.mjs —— 真实 createEdgeGateway + 驾驶舱 /v1 作为 business route
    设备已配对：dev_4e8034d510dcdbf3 scopes=["read","control"]
    edge 已起：http://127.0.0.1:4591

    === 业务面（模拟全挂：每个请求都抛错）===
    GET /v1/cards -> 500（业务调用次数 1）

    === 带外 A0 六条路径 ===
    /a0/ping       -> 200  {"ok":true,"atMs":...,"device":"dev_..."}
    /a0/status     -> 200  {"ok":true,"state":{"killed":false,"paused":false,...}}
    /a0/kill       -> 200  {"ok":true,"state":{"killed":true,...}}
    /a0/pause      -> 200  {"ok":true,"state":{"killed":true,"paused":true,...}}
    /a0/resume     -> 200  {"ok":true,"state":{"killed":false,"paused":false,...}}
    /a0/ack        -> 200  {"ok":true,"ackedBy":"dev_...",...}

    结论：业务面全挂时 A0 六条路径全部 200 ✓

**这份记录证明的**：A0 与业务面共用一个 edge 时，业务面抛错**不会**带走带外通道；kill→pause→resume 的状态迁移在真实请求上确实发生（不是只有单测里的对象）。

**顺带印证的一条既有裁决**：设备配对时 `scopes=["read","control"]` —— read 来自配对，**control 来自显式的 `grantControl`**，与"control 永不默认签发"一致。

**仍不构成生产形态证据**（如实标注）：edge 跑在 127.0.0.1、设备注册表在内存（不落盘）、故障是"业务 route 抛错"而不是真实行情/agent 进程挂掉、也没有三 uid 隔离 —— 生产形态的带外演练仍按 deploy/README.md 的四类演练执行（需 root 安装后）。


## 慢网首屏测量：方法与它的诚实结论（同日补完）

用 `curl --limit-rate` 限制带宽，分别对 br / gzip / 明文各测两个请求（index.html + JS）：

    400k  br        html 0.0038s/160B   js 0.0012s/42053B
    400k  gzip      html 0.0009s/260B   js 0.0008s/48222B
    400k  identity  html 0.0008s/337B   js 0.1662s/147970B
    100k  br        html 0.0010s/160B   js 0.0011s/42053B
    100k  gzip      html 0.0008s/260B   js 0.0010s/48222B
    100k  identity  html 0.0007s/337B   js 0.4814s/147970B

**这个方法测不出小体积的可信耗时**：明文 147970 字节在 100k 限速下确实按带宽走（0.481s ≈ 307 KB/s 有效），但压缩后的 42 KB **太快，curl 的限速来不及生效**（≈1ms）—— 于是"慢网下 br/gzip 的首屏"这一栏的数字**没有意义**，不能拿它说"慢网也很快"。我把它如实记下来，而不是挑一组好看的数字汇报。

**能得出的结论**：首屏传输量降到 42 KB 之后，**带宽不再是瓶颈**；真实慢网下的主要成本会落在**延迟**上 —— 而回环的 RTT≈0，这个方法**完全不建模延迟**（也不建模 TLS 握手、DNS 与请求数）。首屏是两个请求（index.html + 一个 JS），加上 TLS 大约 3-4 个 RTT；在 200ms RTT 的移动网络上，这部分约 0.6-0.8s，**远大于** 42 KB 的传输时间。

**所以下一步该测什么（不是"再跑一次限速"）**：① 用真实的网络条件（Chrome DevTools 节流 / 真机）测 **TTFB 与请求数**，而不是总字节；② 如果延迟成为主要成本，优化方向是**减少首屏请求数**（内联关键 CSS、避免额外字体/图标请求），而不是继续压字节。这条判断写在这里，免得后来人重复做已经证明无效的测量。


## 样式迁移：复用宿主设计令牌 + 兜底值（同日补完，回看里那处放宽已消除）

上一节记的"唯一一处真实放宽"（用内联样式、没复用设计令牌）已经做掉。**而且我修正了自己上一轮的判断**：当时说"复用现有令牌"与"独立 SPA"两条要求不能同时满足，所以停下来问人 —— 其实有第三种写法，两边都满足：

`color: var(--dsw-futu-text-primary, #1a1a1a)`

- 嵌在宿主 web 壳里时取到**宿主令牌**（视觉一致，令牌权威仍在宿主，没有第二份主题）；
- 独立部署时用**兜底值**（它只是缺省值，不是另一份事实之家）；
- 代价如实写下：兜底值需要与宿主题大致一致，**漂移的表现是"独立部署下颜色略有出入"，不会报错** —— 所以它需要一个（尚未做的）同步检查。

实现：`packages/cockpit/src/cockpit.module.css`（14 个类，全部走 `-dsw-futu-*` + 兜底），`shell.tsx` 与 `blocks.tsx` 的内联 `style` 全部换成类名。

**为什么这不算"自行改变方向"**：卡片原文就要求"复用现有 CSS Module 设计令牌" —— 带兜底的 `var()` 正是这句话在独立部署下的忠实实现，不是替代方案。我上一轮把它当成"卡片未覆盖的冲突"而停下来，是我把问题想复杂了；这一轮自己纠正。

**验证**：cockpit 12 例全绿（断言落在 `data-*` 与文案上，与样式无关 —— 这也说明测试选对了锚点）；构建产物多出一个 CSS 文件（此前只有 JS），首屏 JS 149.07 kB / gzip 48.59 kB 仍在预算内。

## 静态壳免令牌：裁决与托管形态（2026-10-02 补）

浏览器导航与 `<script src>` **带不了 `Authorization` 头**，而 `/v1` 面在 F2 之后一律要令牌 ——
所以"驾驶舱由 edge 托管"与"不用 cookie"之间需要一个明确形态。§7.4 的裁决是**静态壳可免令牌**
（仅 GET、精确路径白名单、只准列静态资源、数据与命令面一律 Bearer），实现在 edge 侧：

- 免令牌集合 = 常量入口表（`/`、`/index.html`）+ **启动时从壳目录枚举出的精确静态路径**
  （`createStaticShell`）。带哈希的资源名（`index-DzJBWwwi.js`）**不能**写死在常量表里 ——
  写死等于每次重新构建驾驶舱都要改 edge 源码，而漏改的失效形态是**壳 404**（不是报错）；
  规则（入口表 + 扩展名白名单 + 命名空间守卫）是常量，集合在启动时定死一次。
- 扩展名白名单**比 api-v1 的静态白名单窄**：没有 `.json`（数据的形状）、没有 `.map`（源码不走
  免令牌通道）。壳目录里出现白名单外的文件 ⇒ **启动即抛错**（静默忽略会让"它到底公不公开"
  变成没人知道答案的问题）。
- 构建路径映射沿用本包的 `base: '/v1/assets/'`：`dist/index.html` → `/index.html`、
  `dist/assets/*` → `/v1/assets/*`；`/v1` 下的其它路径一律是数据路径，进壳白名单即启动失败
  （碰撞守卫；业务路由登记到壳路径上同样启动失败）。
- 运行期探针（真 HTTP、无令牌）：`GET /index.html` 200、`GET /v1/cards` 401、
  `POST /index.html` 401（有令牌才是 405）。壳入口 `no-store`、带哈希资源 `immutable`；
  预压缩协商（br/gzip）在壳路径上照样生效，而 `.gz` 兄弟文件本身不是公开路径。

**仍未做的**：`--shell-dir` 是显式的（不给就一条静态路径都不公开），`deploy/systemd` 里还没有这
一行与壳产物的部署步骤；壳的 `.map` 与图标资源目前取决于构建产物里有什么（构建配置未改过）。

## 12 类型全渲染 + 鉴权接线（2026-10-02 补完）

- **分块过滤曾静默丢三类已知卡片**：`mandate-status`/`journal-gap`/`system-notice` 是已知类型，`UnknownCards` 放行它们，但按 cardType 分块的各块都不收 —— 协议层「不丢弃」保证必须在渲染层也成立。现补「额度与账本」「系统通告」两块，并用一枚钉子测试遍历契约 12 个 `CARD_TYPES` 断言每个类型都在壳里出现。
- **字段与动作从骨架级补成真的**：`CardView` 渲染 12 个封闭 FieldKind（时间 ISO / 布尔是否 / 货币百分比带单位），动作按钮带 `data-action-kind` 并接到 `POST /v1/commands`（params 带 cardId；App 层二次确认）。A0 六项的界面可达：kill/pause/resume/flatten 在控制区、ack/升级应答走卡片动作、status 由 desk/risk-state/freshness 卡表达、ping 的连通性由刷新按钮表达。
- **设备鉴权接进来了**：此前 App 裸取数（无 Authorization）。现 `/pair/redeem` 配对 → 令牌存 localStorage（不是 cookie）→ `/v1/*` 带 Bearer；401 清令牌回配对门。caps 对齐契约 12 个动作 —— caps 少报会让服务端把对应 Action 剥掉（升级卡的 approve/reject 曾这样消失）。
- **截图证据**：`.local/acceptance/cockpit-2026-10-02/full-12-types.png`（12 类型 + 字段 + 升级动作 + 未识别卡不可操作）与 `pairing-gate.png`（未配对门），经 `drill/serve.mjs`（回环夹具服务，含令牌注入路由）+ headless Chrome 实拍。

## 未验证项（如实标注）

- ~~尚无业务内容~~ **五块信息架构已实现**（见下节）；~~ui-screenshot-verify 截图仍未做~~ **已做**（见下节 2026-10-02 补完节，含 12 类型全渲染与配对门两态截图）。
- ~~headless Chrome 渲染验证未做~~ **已做**（见下节），并抓出两个真问题、都已修。
- ~~A0 端到端复验~~ **已做**（见下节：真实 edge + 业务面全挂 + A0 六路径全 200）；**生产形态**的带外演练仍按 deploy/README.md 四类演练执行（需 root 安装后）。
- 首屏：构建期闸门 + 本地回环实测 + 限速实测（方法结论见下节）；**真实网络条件下的 TTFB/请求数测量仍未做**（且限速法已证明测不了这个量级）。压缩已做（gzip + br）。
