# Agent Note: 角色预设与市场能力整合（大师 + 三专员）

Status: implemented

## Problem

四个市场各自生成交易员预设，跨市场研究被迫切换角色；研究与执行共用连接器，难以表达独立研究和风险审查。旧安装器仅验证管理戳格式，保留戳的用户改动会被升级覆盖。

## Decision

base 新增唯一角色安装器，从 loader 的有效启用市场 bundle 行获取能力资产，生成 master（大师）、trader（交易员）、instrument-researcher（标的分析研究员）、risk-reviewer（风险审查员）。原市场 host 行保留配置兼容，但不再写旧预设。市场 connector realm 与路由、安全默认值继续由市场资产拥有；共享知识库、持仓等 host 行不复制入角色。

master 是全能型多 agent 团队主导者：组合形态 = trader 的市场连接器/kit 行 + base 捆绑技能（company-analysis、weekly-trading-plan、content-insight、dynamic-capabilities）+ 三个 `@deepseek-ai/dsh-tool-subagent` 委派实例（provider: fork，backgroundMode: one-shot）。每个实例绑定一个专员 persona——`researcher_subagent` 携带标的分析研究员纪律、`trader_subagent` 携带交易员纪律、`risk_reviewer_subagent` 携带风险审查员纪律——并统一追加一次性子代理边界（只产分析与建议文本，不下单不撤单，执行由大师会话过审批闸门完成）。owner 要求细分问题（标的分析、交易计划草拟、方案复核）委派给对应子代理，交叉核对后整合单一结论；交易执行仍走 dry-run 默认与审批闸门。委派行不 provide 服务，无需 realm；宿主 base 层已常驻 `subagents` 服务与 fork 后端，工具行默认禁用、由预设按需挂载（同官方 standard 的分工）。

master persona 编排四步（2026-09-06 编排升级）：①资金持仓先行——凡交易计划/仓位/敞口/复盘任务先 `holdings_list` 读统一资产台账（含待确认区），实盘资金用各市场 `*_get_balance` / `crypto_get_positions` 核实，不足即询问用户，绝不编造；持仓截图走 `holdings_stage` 入待确认区并提醒确认。②知识先行——任务书携带已命中知识卡片 id 与时效，让子代理共享同一情报基础。③技能与工具调度——按任务类型点名 company-analysis / crypto-instrument-analysis / 对应市场 risk-checklist / trading-strategy-paradigms（配 `strategy_backtest` 验证）/ indicator-authoring / knowledge-curation，一次性跨标的聚合按 dynamic-capabilities 开 dsh-tool-cordis 动态包（禁止绕闸），自选股维护用 watchlist 工具；技能名以会话技能目录实际挂载为准。④交叉裁决——核对行情、台账与公告后整合，交付单一结论并标注来源归属与数据时间。

研究和风险角色只挂市场 kit、base 的只读行情工具与公司分析技能，不挂交易连接器。ticker/K线每次按 host 行情注册表当前路由读取，不提供下单/撤单。master 与 trader 挂连接器后不重复挂只读行情行，避免同名工具先到先得告警。公司分析技能连同 references、templates、scripts 随 base 完整分发。人设先查知识库，再主动获取新闻/公告与基本面，证据不足如实降级。风险审查输出审查意见、压力损失与否决条件，不代替用户交易审批。

安装器校验管理戳与正文 hash；任一角色文件被接管或修改时保留整个角色。旧四市场目录仅在两份文件均未修改、没有额外文件且替代角色均成功提供时，移动到 roster root 外的同级 .legacy-backup；备份名永不覆盖，自定义目录绝不删除。（2026-09-16 修订：备份已存在且名册副本与之逐字节相同时改为删除名册副本、内容不同则另名归档，不再跳过退役；见 [2026-09-16-legacy-preset-retirement-deadlock.md](../bug-fix/2026-09-16-legacy-preset-retirement-deadlock.md)。）

## Alternatives considered

继续四个安装器同时改写统一预设：存在丢市场和并发覆盖风险，拒绝。把四市场依赖全部放 base：破坏部分市场安装，拒绝。研究角色挂交易连接器仅靠人设禁下单：工具面仍暴露执行能力，改用只读适配入口。将公共知识工具复制进各角色：重复注册且违背既有 host 共享决策，拒绝。

大师子代理直接挂 instrument-researcher 预设：dsh-tool-subagent 契约无按调用选预设的参数，预设是会话级组合，子代理无法另挂预设——拒绝。改用独立 spawn 子代理：新会话拿不到市场工具，细分分析无数据可用——拒绝。fork 子代理 + 专员 persona 胜出：继承会话工具面保证研究能力，persona 是 SDK 支持的按子代理角色注入点。

## Consequences

角色按安装市场稳定合成，静态证据纪律置于 persona，实时业务数据不写入组合。定向测试覆盖16种市场子集、顺序稳定、realm保留、仅一个persona、实际kit工具注册、只读行情执行、路由变化、不可用降级、幂等、卸载市场刷新、修改戳保护、旧目录迁移和symlink拒绝；master 断言三个委派实例、交易员 persona 内嵌、一次性子代理边界三现，以及台账先行（holdings_list/holdings_stage）与技能调度（dynamic-capabilities、strategy_backtest、knowledge-curation）关键词。role-skills provider 以独立测试覆盖候选名册、正文可读与未知技能拒绝；dynamic-capabilities 资产本已随 base 分发但此前未注册进技能面，属补齐而非新增资产。**2026-10-12 更新**：content-insight 同样注册进候选（仅 master 与无白名单方可见），原先的否决理由「其脚本与引用资源未随包分发，注册会形成不可执行技能」已不成立——`sync-skills.mjs` 的 `PORTABLE_SKILLS` 收入该技能后 `scripts/`、`references/`、`evals/` 随 base 分发，SKILL.md 另补了非 Apple Silicon 的 V2 降级路径（见 [技能分配](2026-09-06-role-skill-distribution.md)）。

源码级检查确认 loader Entry.disabled 包含祖先禁用。最初使用的 SDK 原生 inject.loader.await 拦截配置随后实测会将安装器自身异步初始化计入待办；现改为普通 loader 注入，按已登记的启用市场行显式导入贡献，见 [2026-09-12 启动修正](../bug-fix/2026-09-12-builtin-plugin-inventory-and-upgrade.md)。真实 standingKeyFor/新会话挂载未在本轮子任务验证，仍需宿主验收。共享 host 动态能力仍存在，因此“不挂订单工具”不是独立安全沙箱。newsRegistry 改为每次注册独立 token，注销仅删除自身注册，最后注册退出时恢复前一聚合器；相同函数的多角色注册不再互相注销，测试覆盖重复dispose及恢复。未改已安装目录或运行中宿主。

master 委派边界如实声明：fork 子代理继承会话工具面（含下单工具可见），专员 persona 约束职责，与「角色分工不是独立安全沙箱」同一信任口径；委派工具仅 master 预设挂载，其他角色与默认会话不可见（宿主默认委派行 disabled）。子代理结论经 master 交叉核对，最终交付物是整合结论而非子代理原文；交易员子代理同样只产计划文本，实际下单只发生在大师会话的审批闸门之后。

编排升级（三专员委派 + 台账先行 persona + dynamic-capabilities 技能注册）经 16 子集组合测试与 base 全套单测（27 例）验证；persona 与委派行属安装器静态产物，真机生效以下一次宿主重启后安装器幂等重写托管预设为准，真机委派验收沿用本文「真机端到端验收」方法复核。

真机端到端验收（2026-09-06，trading-web 独立实例）：boot 安装器写出 master（preset.yml order 90，agent.cordis.yml 23 行合法 YAML）；经定时任务以 agentPreset=master 手动运行委派验收指令，会话头确认 `agentPreset: "master"`，转写含 `subagent/descriptor`（provider fork、one-shot、标签「AAPL 主导价值驱动类型判定」）——master 真实调用 researcher_subagent；行为链符合人设：先 knowledge_search（0 卡如实说明）、调 us_get_ticker/us_get_fundamentals/routing_get、交付整合判定并声明未执行交易。同轮修正安装器与预设副本后桌面壳重启即带 master。验收任务已删除，台账无残留。

默认预设裁决（2026-09-06，owner）：base 的 agent-presets 覆盖行 `default: standard` → `default: master`——角色整合完成且 master 委派链路验收通过后，部署层新会话默认进「大师」。取代 S3 期「default 保持官方 standard、不劫持默认 preset」的过渡口径（该口径的历史语境是四市场各自预设并存的会话选择问题，统一角色后不复存在）；官方 standard 及用户创作预设仍在 roster 可选。owner 同日裁决：本机全局 `~/.dsh/settings.yaml` 的用户层覆盖 `agent-presets.default: ptc` 保留不动（用户层优先于组合层，跨 profile 生效）——因此本机 trading-web 新会话实际默认仍是 ptc，`default: master` 对无用户层覆盖的干净部署生效；headless 部署不受影响（base 该行在 headless 仅警告跳过，默认预设由部署方自行配置）。

已知缺陷（2026-09-06 晚实证，宿主 SDK rc.1 层，非本仓可修）：**创建后切换预设（GUI 会话头 picker → `agentPresets/select`）只切工具面、不切系统提示词 persona**。证据：6 个含 `agent-preset/selected` 事件的会话（含 master、instrument-researcher 目标）request/header 全部保留创建时 persona，无一跟随；同会话工具面切换成功（研究员会话可调 cn_get_* 工具）——形成「工具是研究员、纪律是默认」的半切换状态。对照组：创建时绑定（定时任务 agentPreset=master）与 fork 委派子代理的 per-child persona 均正确注入。根因收窄至 SDK 的 blank-session select 路径（swap→recompose→rebind 对 tools 注册表生效、对 systemPrompt ScopedLayers 不生效；静态阅读 dsh-scope/dsh-system-prompt 显示应为动态解析，疑似 rc.1 实现缺陷）。**Workaround：在 Settings 把默认预设写成目标角色后新建会话**（创建时绑定 100% 生效），不要依赖会话内切换；已半切换的会话废弃重建。

## 0.1.7 cohort 迁移（2026-09-23）：磁盘 roots → agent-preset-registry 运行时注册

0.1.7 官方停发 `@deepseek-ai/dsh-agent-presets` 并删除磁盘 roots 机制（preset 定义
改为 Cordis 行声明 + `ctx.agentPresets.register()`，registry 由 web-app 层
`agent-preset-registry` 行提供）。本 note 的安装器产物形态整体变更：

- `composePresets` 产出对象形 `PresetDefinition`（id/name/description/order/plugins），
  原 agent.cordis.yml + preset.yml 两文件结构 1:1 映射（preset.yml 三字段进
  definition 元数据；plugins 数组即原行列表）。市场贡献仍以 YAML 文本分发（市场包
  资产不动），base 侧用 `yaml` 单点解析（`marketRowsOf`）。
- 安装器 `@dshtrading/base/presets` 改为 `inject: ['loader', 'agentPresets']`，
  对每个角色 definition 先过官方 `entryListProblem` 校验再 register，返回 disposer
  （cordis 插件卸载时释放）。管理戳/写盘/legacy 目录退役逻辑随 roots 机制整体删除。
- `default: master` 的 owner 裁决不变，载体从覆盖 agent-presets 行改为覆盖
  `agent-preset-registry` 行（见
  [2026-08-29-agent-presets-row-host-asymmetry](2026-08-29-agent-presets-row-host-asymmetry.md)
  的 0.1.7 段）。headless 部署契约同款：profile 层 insert registry 行；registry
  服务是安装器的硬 inject，缺行时安装器行永久 pending（部署方必须 insert）。
- 用户层 settings 的 `agent-presets.default` 覆盖键随行 id 演进为 registry 的
  default（本机 `~/.dsh/settings.yaml` 的 `agent-presets.default: ptc` 用户层覆盖
  需要对应迁移；owner 2026-09-06 裁决的「用户层优先」口径不变）。
- 已知宿主缺陷记录保留：0.1.5 实测的「创建后切预设不切 persona」在 0.1.7 的
  复验纳入本轮 profile 验收清单（registry 时代 select 路径重写，可能已修复）。
- （2026-10-03 owner 裁决）trading-web 的名册只保留本仓四角色：官方内置四条
  （standard / ptc / minimal / cordis）在 profile 级 `cordis.patch.yml` 按 id 覆盖
  `disabled: true` 屏蔽。它们不是磁盘文件，而是 `@deepseek-ai/dsh-web-app` 的
  `presets/*.patch.yml` 在 boot 时 insert 的声明行（0.1.7 起 harness 不再扫磁盘
  roots，预设中心只管 `$DSH_HOME/agent-presets/` 的市场下载），所以「删除」= 按 id
  覆盖禁用，行仍在组合树里但不向 `agentPresets` 注册；不改 `node_modules` 与官方包。
  生效边界：新会话与 GUI 名册立即按新组合解析；运行中的宿主不重挂已挂 fiber
  （`patchReload: live` 的既有口径，见
  [indicator-plugin-split](2026-08-30-indicator-plugin-split.md)），需重启宿主才
  在 GUI 里看到名册变化。默认预设 `master` 不受影响（`preset-ptc` 已不被任何默认
  引用）。副作用如实记录：`cordis` preset 是官方「让 Agent 帮我创建预设模式」入口与
  `cordis_inspect_*` / Plugin Manager 工具面的唯一载体（`dsh-client-ui-agent-preset`
  仅在名册存在 id `cordis` 时渲染 Creator 按钮；见
  [dynamic-capabilities](../../../skills/dynamic-capabilities/SKILL.md) 第 1 节）；禁用后
  trading-web 不再有该通路，需要时删掉对应条目即可恢复。桌面壳重播种保留
  `cordis.patch.yml*`，升级 / 重装后该节仍在。
- （2026-10-21）名册条目数补充：本仓另声明三个委派专用 preset（`dsh-trading-delegate-*`，角色行 +
  委派纪律，供 master 的三个委派工具用），它们与本仓四角色一样会进名册，所以名册实际是
  master / trader / instrument-researcher / risk-reviewer + 三个「（委派）」条目。registry 契约没有
  可见性字段、GUI 只按 `broken` 过滤，对用户隐藏委派 preset 这条路不存在；用途靠名称后缀与靠后的
  order 表达。细节见 2026-10-21 SDK 升级 note 的「同日续三」。
