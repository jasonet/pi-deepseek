import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const {
  resolveRuntimePaths,
  isTradingHomePath,
  selectDshHome,
  consoleMessageArgsToEntry,
  rendererLogLine,
  RENDERER_LOG_LINE_MAX,
  resolvePrimaryRuntime,
  profileSeedFingerprint,
  runtimeSeedStamp,
  profileAction,
  applyProfileSeed,
  parseShasums,
  waitForTokenUrl,
  parseTokenUrlLine,
  formatHostExitDiagnostic,
  formatHostExitLine,
  planHostRecovery,
  createTokenUrlCollector,
  isNavigationFailureFor,
  HOST_RECOVERY_MAX,
  HOST_RECOVERY_WINDOW_MS,
  asarUnpackedPath,
  toNodeImportSpecifier,
  normalizeProfileCohort,
  SEED_MARKER,
} = require('../src/runtime.cjs');

test('resolveRuntimePaths picks the platform node binary', () => {
  const mac = resolveRuntimePaths('/res', 'darwin', 'arm64');
  assert.equal(mac.nodeBin, path.join('/res', 'runtime', 'node', 'bin', 'node'));
  const win = resolveRuntimePaths('C:\\res', 'win32', 'x64');
  assert.equal(win.nodeBin, path.join('C:\\res', 'runtime', 'node', 'node.exe'));
  assert.ok(mac.hostBin.endsWith(path.join('@deepseek-ai', 'dsh', 'lib', 'bin.js')));
});

test('resolveRuntimePaths keeps the per-platform dir unpackaged', () => {
  const dev = resolveRuntimePaths('/res', 'darwin', 'arm64', false);
  assert.equal(dev.nodeBin, path.join('/res', 'runtime', 'node-darwin-arm64', 'bin', 'node'));
  const devWin = resolveRuntimePaths('/res', 'win32', 'x64', false);
  assert.equal(devWin.nodeBin, path.join('/res', 'runtime', 'node-win32-x64', 'node.exe'));
});

test('operator falls back to the trading home when DSH_HOME is unset or blank', () => {
  // Given a Dock launch (no environment) and an explicitly blank value
  // When the managed home is selected
  const unset = selectDshHome({}, '/home/u');
  const blank = selectDshHome({ DSH_HOME: '   ' }, '/home/u');

  // Then both fall back to the built-in trading home and nothing is reported as ignored
  assert.equal(unset.home, path.join('/home/u', '.dsh-trading'));
  assert.equal(unset.ignored, undefined);
  assert.equal(blank.home, path.join('/home/u', '.dsh-trading'));
  assert.equal(blank.ignored, undefined);
});

test('operator keeps an explicit trading-home DSH_HOME and still expands ~', () => {
  // Given explicit DSH_HOME values whose path contains -trading
  // When the managed home is selected
  const tilde = selectDshHome({ DSH_HOME: '~/probe-trading' }, '/home/u');
  const absolute = selectDshHome({ DSH_HOME: '/data/dsh-trading' }, '/home/u');
  const windowsTilde = selectDshHome({ DSH_HOME: '~\\probe-trading' }, '/home/u');

  // Then the value wins with ~ expanded against the home directory, and nothing is reported as ignored
  assert.equal(tilde.home, path.join('/home/u', 'probe-trading'));
  assert.equal(absolute.home, path.resolve('/data/dsh-trading'));
  assert.equal(windowsTilde.home, path.join('/home/u', 'probe-trading'));
  assert.deepEqual([tilde.ignored, absolute.ignored, windowsTilde.ignored], [undefined, undefined, undefined]);
  assert.equal(isTradingHomePath('/Users/u/.dsh-trading'), true);
});

test('operator ignores an inherited DSH_HOME that is not a trading home', () => {
  // Given the host instance's home, an unrelated custom home, and a bare ~ inherited by the launch shell
  // When the managed home is selected
  const host = selectDshHome({ DSH_HOME: '~/.dsh' }, '/home/u');
  const custom = selectDshHome({ DSH_HOME: '~/custom' }, '/home/u');
  const hostAbsolute = selectDshHome({ DSH_HOME: '/Users/u/.dsh' }, '/home/u');

  // Then each is ignored, reported verbatim for the warning line, and the trading home is used
  assert.equal(host.home, path.join('/home/u', '.dsh-trading'));
  assert.equal(host.ignored, '~/.dsh');
  assert.equal(custom.home, path.join('/home/u', '.dsh-trading'));
  assert.equal(custom.ignored, '~/custom');
  assert.equal(hostAbsolute.home, path.join('/home/u', '.dsh-trading'));
  assert.equal(hostAbsolute.ignored, '/Users/u/.dsh');
  assert.equal(isTradingHomePath('/Users/u/.dsh'), false);
  assert.equal(isTradingHomePath(undefined), false);
});

test('operator logs renderer warnings and errors and drops the info chatter', () => {
  // Given console messages the renderer emits, at every level
  // When they are rendered as host log lines
  const warn = rendererLogLine({
    level: 'warning',
    message: 'failed to fetch custom indicators',
    source: 'http://127.0.0.1:8888/plugins/??a.js',
    line: 42,
  });
  const error = rendererLogLine({ level: 'error', message: 'Uncaught Error: boom' });
  const alias = rendererLogLine({ level: 'warn', message: 'aliased warning' });

  // Then warn/error reach the log prefixed [renderer] with their source, and info/debug do not
  assert.equal(
    warn,
    '[renderer] warning http://127.0.0.1:8888/plugins/??a.js:42 failed to fetch custom indicators',
  );
  assert.equal(alias, '[renderer] warning aliased warning');
  assert.equal(error, '[renderer] error Uncaught Error: boom');
  assert.equal(rendererLogLine({ level: 'info', message: 'GUI ready' }), undefined, 'info must be dropped');
  assert.equal(rendererLogLine({ level: 'debug', message: 'trace' }), undefined, 'debug must be dropped');
});

test('operator stores a renderer message as a single log line', () => {
  // Given a renderer message that spans several lines
  // When it is rendered
  const line = rendererLogLine({ level: 'warn', message: 'first\n  second\nthird' });

  // Then the newlines collapse to spaces so one message stays one record
  assert.equal(line, '[renderer] warning first second third');
});

test('operator truncates an overlong renderer log line at the 500 character cap', () => {
  // Given a renderer message far longer than the line budget
  const message = 'x'.repeat(4000);

  // When it is rendered
  const line = rendererLogLine({
    level: 'error',
    message,
    source: 'http://127.0.0.1:8888/plugins/??b.js',
    line: 7,
  });

  // Then the line fits the cap, keeps the head that identifies it, and marks the truncation
  assert.equal(line.length, RENDERER_LOG_LINE_MAX);
  assert.ok(line.startsWith('[renderer] error http://127.0.0.1:8888/plugins/??b.js:7 '));
  assert.ok(line.endsWith('...[truncated]'));
});

test('管理员从超长 combo URL 的渲染进程报错行里读到原因', () => {
  // Given a renderer error whose source is a 2.8 KiB client-plugin batch URL
  const source = 'http://127.0.0.1:59547/plugins/??' + 'x'.repeat(2800);

  // When the message is rendered
  const line = rendererLogLine({
    level: 'error',
    message: 'Failed to load resource: the server responded with a status of 431 (Request Header Fields Too Large)',
    source,
    line: 0,
  });

  // Then the reason survives the line cap, and the shortened source says what it dropped
  assert.ok(line.includes('status of 431'));
  assert.ok(line.includes('…(+'));
  assert.ok(line.length <= RENDERER_LOG_LINE_MAX);
  assert.ok(line.startsWith('[renderer] error http://127.0.0.1:59547/plugins/??'));
});

test('operator reads both the Electron details object and its legacy positional arguments', () => {
  // Given Electron 44's console-message details object and the older positional form
  // When each is normalized for the log formatter
  const details = consoleMessageArgsToEntry(
    { level: 'warning', message: 'w', sourceId: 'http://x/a.js', lineNumber: 3 }, 1, 'deprecated');
  const legacy = consoleMessageArgsToEntry({ preventDefault() {} }, 2, 'old warning', 9, 'http://x/b.js');

  // Then both describe the same fields, and the legacy 0..3 level maps to its name
  assert.deepEqual(details, { level: 'warning', message: 'w', source: 'http://x/a.js', line: 3 });
  assert.deepEqual(legacy, { level: 2, message: 'old warning', source: 'http://x/b.js', line: 9 });
  assert.equal(rendererLogLine(legacy), '[renderer] warning http://x/b.js:9 old warning');
  assert.equal(
    rendererLogLine(consoleMessageArgsToEntry({ preventDefault() {} }, 3, 'legacy error')),
    '[renderer] error legacy error',
  );
  assert.equal(
    rendererLogLine(consoleMessageArgsToEntry({ preventDefault() {} }, 1, 'legacy info')),
    undefined,
    'legacy verbose/info levels are dropped too',
  );
});

test('profileAction seeds missing, leaves user-managed, reseeds stale', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-profile-action-'));
  const profile = path.join(dir, 'web');
  assert.equal(profileAction(profile, 's1'), 'seed');

  fs.mkdirSync(profile, { recursive: true });
  fs.writeFileSync(path.join(profile, 'package.json'), '{}');
  assert.equal(profileAction(profile, 's1'), 'leave', 'no marker means user-managed');

  fs.writeFileSync(path.join(profile, SEED_MARKER), JSON.stringify({ stamp: 's1' }));
  assert.equal(profileAction(profile, 's1'), 'leave', 'current stamp is up to date');
  assert.equal(profileAction(profile, 's2'), 'reseed', 'moved stamp triggers reseed');
});

test('bundled plugin updates reseed managed profiles without changing the host version', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-plugin-seed-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const seed = path.join(dir, 'seed');
  const profile = path.join(dir, 'profile');
  const plugin = path.join(seed, 'node_modules', '@dshtrading', 'client-ui-updater');
  fs.mkdirSync(plugin, { recursive: true });
  fs.writeFileSync(path.join(seed, 'package.json'), '{"name":"dsh-profile-trading-web"}');
  fs.writeFileSync(path.join(seed, 'cordis.patch.yml'), '[]\n');
  fs.writeFileSync(path.join(plugin, 'package.json'), '{"version":"0.5.9"}');
  fs.writeFileSync(path.join(plugin, 'index.js'), 'old bundle');
  const runtime = { node: 'node@24', host: 'dsh@0.1.5-rc.1' };
  const initialHash = profileSeedFingerprint(seed);
  const initial = runtimeSeedStamp({ ...runtime, profileHash: initialHash });
  applyProfileSeed(seed, profile, 'seed', initial, {});
  fs.writeFileSync(path.join(profile, 'cordis.patch.yml'), '- id: user-setting\n');

  const copy = path.join(dir, 'copy');
  fs.cpSync(seed, copy, { recursive: true });
  fs.utimesSync(path.join(copy, 'package.json'), new Date(0), new Date(0));
  assert.equal(profileSeedFingerprint(copy), initialHash, 'copy location and timestamps do not affect identity');
  assert.equal(runtimeSeedStamp({ ...runtime, profileHash: initialHash, builtAt: 'later' }), initial);
  assert.equal(profileAction(profile, initial), 'leave');

  fs.writeFileSync(path.join(plugin, 'package.json'), '{"version":"0.6.1"}');
  fs.writeFileSync(path.join(plugin, 'index.js'), 'rebuilt bundle');
  const updated = runtimeSeedStamp({ ...runtime, profileHash: profileSeedFingerprint(seed) });
  assert.notEqual(updated, initial);
  assert.equal(profileAction(profile, updated), 'reseed');
  applyProfileSeed(seed, profile, 'reseed', updated, {});
  assert.equal(fs.readFileSync(path.join(profile, 'node_modules', '@dshtrading', 'client-ui-updater', 'package.json'), 'utf8'), '{"version":"0.6.1"}');
  assert.equal(fs.readFileSync(path.join(profile, 'cordis.patch.yml'), 'utf8'), '- id: user-setting\n');
  assert.equal(profileAction(profile, updated), 'leave');

  fs.writeFileSync(path.join(plugin, 'index.js'), 'same-version rebuild');
  assert.notEqual(runtimeSeedStamp({ ...runtime, profileHash: profileSeedFingerprint(seed) }), updated);
  fs.rmSync(path.join(profile, SEED_MARKER));
  assert.equal(profileAction(profile, initial), 'leave', 'user-managed profiles remain untouched');
});

test('runtimeSeedStamp accepts legacy stamps and upgrades their managed profiles', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-legacy-seed-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  assert.equal(runtimeSeedStamp(undefined), 'unknown');
  assert.equal(runtimeSeedStamp({ node: 'n', host: 'h', webAll: 'legacy' }), 'n / h / legacy');
  const legacy = runtimeSeedStamp({ node: 'n', host: 'h', trading: 'base' });
  assert.equal(legacy, 'n / h / ');
  fs.writeFileSync(path.join(dir, 'package.json'), '{}');
  fs.writeFileSync(path.join(dir, SEED_MARKER), JSON.stringify({ stamp: legacy }));
  const current = runtimeSeedStamp({ node: 'n', host: 'h', profileHash: 'profile-content' });
  assert.equal(profileAction(dir, current), 'reseed');
});

test('normalizeProfileCohort relinks core packages onto the bundled runtime', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-cohort-'));
  const bundled = path.join(dir, 'runtime', 'node_modules');
  const foreign = path.join(dir, 'foreign');
  const profile = path.join(dir, 'profiles', 'trading-web');
  const core = path.join(profile, 'node_modules', '@deepseek-ai');
  const writePackage = (pkgDir) => {
    fs.mkdirSync(pkgDir, { recursive: true });
    fs.writeFileSync(path.join(pkgDir, 'package.json'), '{}');
  };
  for (const name of ['dsh-scope', 'dsh-tools', 'dsh-agent-presets']) writePackage(path.join(bundled, '@deepseek-ai', name));
  writePackage(path.join(foreign, 'dsh-scope'));
  fs.mkdirSync(core, { recursive: true });
  // already single-instance: must stay untouched
  fs.symlinkSync(path.join(bundled, '@deepseek-ai', 'dsh-scope'), path.join(core, 'dsh-scope'), 'dir');
  // a foreign install's link and a materialized copy: both must be relinked
  fs.symlinkSync(path.join(foreign, 'dsh-scope'), path.join(core, 'dsh-tools'), 'dir');
  writePackage(path.join(core, 'dsh-agent-presets'));
  // a package the bundled runtime does not ship: must survive
  writePackage(path.join(core, 'dsh-future'));
  // nested shadow copy under a real package tree: must be relinked too
  writePackage(path.join(profile, 'node_modules', '@dshtrading', 'knowledge', 'node_modules', '@deepseek-ai', 'dsh-tools'));
  // a symlinked package tree belongs to another install: must be left alone
  const linkedTree = path.join(dir, 'linked-package');
  writePackage(path.join(linkedTree, 'node_modules', '@deepseek-ai', 'dsh-tools'));
  fs.symlinkSync(linkedTree, path.join(profile, 'node_modules', '@dshtrading', 'linked'), 'dir');

  const result = normalizeProfileCohort(profile, bundled);
  assert.equal(result.failed.length, 0);
  assert.equal(result.relinked.length, 3);
  const bundledReal = (name) => fs.realpathSync(path.join(bundled, '@deepseek-ai', name));
  assert.equal(fs.realpathSync(path.join(core, 'dsh-tools')), bundledReal('dsh-tools'));
  assert.equal(fs.realpathSync(path.join(core, 'dsh-agent-presets')), bundledReal('dsh-agent-presets'));
  assert.equal(fs.realpathSync(path.join(core, 'dsh-scope')), bundledReal('dsh-scope'));
  assert.ok(fs.existsSync(path.join(core, 'dsh-future', 'package.json')), 'unknown package survives');
  assert.equal(
    fs.realpathSync(path.join(profile, 'node_modules', '@dshtrading', 'knowledge', 'node_modules', '@deepseek-ai', 'dsh-tools')),
    bundledReal('dsh-tools'),
    'nested shadow copy is relinked',
  );
  const linkedShadow = path.join(linkedTree, 'node_modules', '@deepseek-ai', 'dsh-tools');
  assert.ok(fs.lstatSync(linkedShadow).isDirectory() && !fs.lstatSync(linkedShadow).isSymbolicLink(), 'a symlinked package tree is never rewritten');
  assert.deepEqual(normalizeProfileCohort(profile, bundled).relinked, [], 'second pass is a no-op');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('applyProfileSeed keeps the user patch layer on reseed', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-seed-'));
  const seed = path.join(dir, 'seed');
  const profile = path.join(dir, 'web');
  fs.mkdirSync(path.join(seed, 'node_modules', 'pkg'), { recursive: true });
  fs.writeFileSync(path.join(seed, 'package.json'), '{"name":"dsh-profile-web"}');
  fs.writeFileSync(path.join(seed, 'cordis.patch.yml'), '[]\n');
  fs.writeFileSync(path.join(seed, 'node_modules', 'pkg', 'index.js'), 'v1');
  fs.writeFileSync(path.join(seed, 'node_modules', 'pkg', 'cordis.patch.yml'), '- insert: [{ id: bundled-v1 }]\n');

  applyProfileSeed(seed, profile, 'seed', 's1', { appVersion: '0.1.0' });
  assert.equal(fs.readFileSync(path.join(profile, 'node_modules', 'pkg', 'index.js'), 'utf8'), 'v1');

  // User edits the patch layer; the seed moves to a new node_modules payload.
  fs.writeFileSync(path.join(profile, 'cordis.patch.yml'), '- insert: []\n');
  fs.writeFileSync(path.join(seed, 'node_modules', 'pkg', 'index.js'), 'v2');
  fs.writeFileSync(path.join(seed, 'node_modules', 'pkg', 'cordis.patch.yml'), '- insert: [{ id: bundled-v2 }]\n');

  applyProfileSeed(seed, profile, 'reseed', 's2', { appVersion: '0.1.1' });
  assert.equal(fs.readFileSync(path.join(profile, 'node_modules', 'pkg', 'index.js'), 'utf8'), 'v2');
  assert.equal(fs.readFileSync(path.join(profile, 'cordis.patch.yml'), 'utf8'), '- insert: []\n', 'user patch survives');
  assert.equal(fs.readFileSync(path.join(profile, 'node_modules', 'pkg', 'cordis.patch.yml'), 'utf8'), '- insert: [{ id: bundled-v2 }]\n', 'bundled patches must be copied on reseed');
  assert.equal(JSON.parse(fs.readFileSync(path.join(profile, SEED_MARKER), 'utf8')).stamp, 's2');
});

test('parseShasums parses SHASUMS256.txt lines', () => {
  const text = 'a'.repeat(64) + '  node-v24.20.0-darwin-arm64.tar.gz\n' + 'b'.repeat(64) + '  node-v24.20.0-win-x64.zip\n';
  const map = parseShasums(text);
  assert.equal(map.get('node-v24.20.0-darwin-arm64.tar.gz'), 'a'.repeat(64));
  assert.equal(map.get('node-v24.20.0-win-x64.zip'), 'b'.repeat(64));
  assert.equal(map.size, 2);
});

test('parseTokenUrlLine extracts the host token URL', () => {
  assert.equal(
    parseTokenUrlLine('dsh web: http://127.0.0.1:34981/?token=abc-DEF_123'),
    'http://127.0.0.1:34981/?token=abc-DEF_123');
  assert.equal(parseTokenUrlLine('[desktop] boot failed'), undefined);
});

test('管理员从带 LAN 后缀的宿主行里取到回环 token URL', () => {
  // Given the host printed its token line for a non-loopback bind, with the LAN URL appended
  const line = 'dsh web: http://127.0.0.1:34981/?token=abc-DEF_123 (LAN: http://192.168.1.5:34981/?token=abc-DEF_123)';

  // When the line is parsed
  const url = parseTokenUrlLine(line);

  // Then the loopback token URL comes back, and the browser-handoff line yields nothing.
  assert.equal(url, 'http://127.0.0.1:34981/?token=abc-DEF_123');
  assert.equal(parseTokenUrlLine('dsh web: opening the default browser; pass --no-open to disable'), undefined);
});

test('用户等到宿主稍后打印的 token URL 才加载，不再落到裸 URL', async () => {
  // Given a host that answers its port before it prints the token line
  const line = 'http://127.0.0.1:51235/?token=late';
  let reads = 0;

  // When the shell waits for the tokenized URL
  const url = await waitForTokenUrl({
    readUrl: () => {
      reads += 1;
      return reads < 3 ? undefined : line;
    },
    isAlive: () => true,
    deadlineMs: 5000,
    pollMs: 1,
  });

  // Then the late tokenized URL is returned, never the bare one.
  assert.equal(url, line);
  assert.ok(reads >= 3);
});

test('用户拿到宿主退出与超时的明确报错，而不是 401 页面', async () => {
  // Given a host that exits before printing its token line, and one that never prints it
  // When the shell waits for the tokenized URL
  const exited = waitForTokenUrl({ readUrl: () => undefined, isAlive: () => false, deadlineMs: 5000, pollMs: 1 });
  const stalled = waitForTokenUrl({ readUrl: () => undefined, isAlive: () => true, deadlineMs: 20, pollMs: 1 });

  // Then both waits fail with a diagnostic instead of returning an unauthenticated URL.
  await assert.rejects(exited, /exited before it printed its tokenized GUI URL/);
  await assert.rejects(stalled, /timed out after .* waiting for the host to print its tokenized GUI URL/);
});

test('formatHostExitDiagnostic detects missing VC++ redistributable on Windows', () => {
  const winUnsigned = formatHostExitDiagnostic(3221225781, null, 'win32');
  assert.equal(winUnsigned.isMissingVCRedist, true);
  assert.ok(winUnsigned.message.includes('0xC0000135'));
  assert.ok(winUnsigned.message.includes('Visual C++'));

  const winSigned = formatHostExitDiagnostic(-1073741515, null, 'win32');
  assert.equal(winSigned.isMissingVCRedist, true);

  const macExit = formatHostExitDiagnostic(3221225781, null, 'darwin');
  assert.equal(macExit.isMissingVCRedist, false);

  const normalExit = formatHostExitDiagnostic(1, null, 'win32');
  assert.equal(normalExit.isMissingVCRedist, false);
  assert.ok(normalExit.message.includes('退出码: 1'));

  const signalExit = formatHostExitDiagnostic(null, 'SIGTERM', 'darwin');
  assert.equal(signalExit.isMissingVCRedist, false);
  assert.ok(signalExit.message.includes('SIGTERM'));
});

test('operator can tell a shell-initiated host stop from a host one in the exit line', () => {
  // Given the same exit shape the shell reports for its own teardown and for a
  // host that stopped on its own (2026-10-15: both read code=0 signal=null)
  const teardown = formatHostExitLine({
    code: 0,
    signal: null,
    quitInitiated: true,
    elapsedMs: 8123.4,
    message: '后台服务进程意外停止。',
  });
  const selfStop = formatHostExitLine({
    code: 0,
    signal: null,
    quitInitiated: false,
    elapsedMs: 900,
    message: '后台服务进程意外停止。',
  });

  // When both lines are read side by side
  // Then the initiating side and the host's age tell them apart
  assert.ok(teardown.includes('code=0 signal=null initiatedBy=shell after=8123ms'), teardown);
  assert.ok(selfStop.includes('code=0 signal=null initiatedBy=host after=900ms'), selfStop);
  assert.ok(selfStop.includes('(后台服务进程意外停止。)'), 'the user-facing message stays on the line');
});

test('operator gets no host age in the exit line when it is not measurable', () => {
  // Given an exit whose elapsed time is absent and one whose elapsed time is not a number
  // When the lines are formatted
  // Then neither invents an age for the operator to read
  const line = formatHostExitLine({ code: 1, signal: null, quitInitiated: false, message: '退出码: 1' });
  assert.equal(line, '[desktop] host exited: code=1 signal=null initiatedBy=host (退出码: 1)');
  const signalled = formatHostExitLine({
    code: null,
    signal: 'SIGKILL',
    quitInitiated: false,
    elapsedMs: Number.NaN,
    message: '被系统信号终止: SIGKILL',
  });
  assert.equal(signalled, '[desktop] host exited: code=null signal=SIGKILL initiatedBy=host (被系统信号终止: SIGKILL)');
});

test('operator gets the host restarted while the restart budget lasts', () => {
  // Given a host that keeps stopping without the shell asking
  const now = 1_000_000;
  let exitTimes = [];

  // When three unexpected exits land back to back
  const plans = [];
  for (let i = 0; i < 3; i += 1) {
    const plan = planHostRecovery({ exitTimes, now: now + i * 1000 });
    plans.push(plan);
    exitTimes = plan.exitTimes;
  }

  // Then each one restarts the host and the attempt counter counts up
  assert.deepEqual(plans.map((plan) => plan.recover), [true, true, true]);
  assert.deepEqual(plans.map((plan) => plan.attempt), [1, 2, 3]);
  assert.equal(exitTimes.length, 3);
});

test('operator gets the startup-problem page once the restart budget is spent', () => {
  // Given three restarts already spent inside the window
  const now = 1_000_000;
  const windowMs = HOST_RECOVERY_WINDOW_MS;
  const exitTimes = [now - 3000, now - 2000, now - 1000];

  // When a fourth unexpected exit lands
  const plan = planHostRecovery({ exitTimes, now });

  // Then recovery stops, so a crash loop ends on the page with the log
  assert.equal(plan.recover, false);
  assert.equal(plan.attempt, 4);
  assert.equal(plan.exitTimes.length, 4);
});

test('operator gets a fresh restart budget after a quiet window', () => {
  // Given three restarts spent longer ago than the window
  const now = 1_000_000;
  const windowMs = HOST_RECOVERY_WINDOW_MS;
  const exitTimes = [now - windowMs - 3000, now - windowMs - 2000, now - windowMs - 1000];

  // When an unexpected exit lands now
  const plan = planHostRecovery({ exitTimes, now });

  // Then the old exits are forgotten and this one is restartable again
  assert.equal(plan.recover, true);
  assert.equal(plan.attempt, 1);
  assert.deepEqual(plan.exitTimes, [now]);
});

test('operator gets the documented restart budget from the shipped constants', () => {
  // Given the constants the shell hands to planHostRecovery
  // When they are read
  // Then the page-facing copy (three attempts, a ten minute window) matches them
  assert.equal(HOST_RECOVERY_MAX, 3);
  assert.equal(HOST_RECOVERY_WINDOW_MS, 600000);
});

test('operator never boots onto the previous host\u2019s URL', () => {
  // Given a collector that saw the first host's tokenized URL
  const urls = createTokenUrlCollector();
  const first = 'http://127.0.0.1:50833/?token=first';
  const second = 'http://127.0.0.1:51089/?token=second';
  urls.observe('dsh web: ' + first);

  // When the next boot clears it and the restarted host prints its own line
  // Then the dead host's URL is gone while it waits, and the new one is read
  assert.equal(urls.read(), first);
  urls.reset();
  assert.equal(urls.read(), undefined);
  urls.observe('dsh web: ' + second);
  assert.equal(urls.read(), second);

  // And host output that carries no tokenized URL leaves it alone
  urls.observe('dsh web: opening the default browser; pass --no-open to disable');
  urls.observe('[renderer] warning: connection lost');
  assert.equal(urls.read(), second);
});

test('operator does not blame the new host for a previous page\u2019s failed reload', () => {
  // Given a dead page's retry failing against the previous port while the new
  // boot asked for its own
  const dead = "ERR_CONNECTION_REFUSED (-102) loading 'http://127.0.0.1:50399/?token=old'";
  const target = 'http://127.0.0.1:50656/?token=new';

  // When the failure is attributed
  // Then only the target's own failure counts as a broken boot
  assert.equal(isNavigationFailureFor(dead, target), false);
  assert.equal(isNavigationFailureFor("ERR_CONNECTION_REFUSED (-102) loading '" + target + "'", target), true);
});

test('operator gets host hook paths that point outside the archive', () => {
  // Given an archived source path on either platform
  // When it is mapped for the external Node runtime
  // Then the unpacked sibling is returned, while unpacked and development paths stay put
  assert.equal(
    asarUnpackedPath('/Applications/DSH Trading.app/Contents/Resources/app.asar/src/host-exit-tracer.mjs'),
    '/Applications/DSH Trading.app/Contents/Resources/app.asar.unpacked/src/host-exit-tracer.mjs',
  );
  assert.equal(
    asarUnpackedPath('C:\\app\\resources\\app.asar\\src\\host-orphan-guard.mjs'),
    'C:\\app\\resources\\app.asar.unpacked\\src\\host-orphan-guard.mjs',
  );

  const unpacked = '/res/app.asar.unpacked/src/host-exit-tracer.mjs';
  assert.equal(asarUnpackedPath(unpacked), unpacked);
  assert.equal(asarUnpackedPath('/repo/desktop/src/host-exit-tracer.mjs'), '/repo/desktop/src/host-exit-tracer.mjs');
});

test('toNodeImportSpecifier converts paths to valid file URLs safe for --import', () => {
  assert.equal(toNodeImportSpecifier(undefined), undefined);

  const localFile = path.resolve('src', 'host-symbol-normalizer.mjs');
  const specifier = toNodeImportSpecifier(localFile);
  assert.ok(specifier.startsWith('file://'));
  assert.ok(specifier.includes('host-symbol-normalizer.mjs'));

  if (process.platform === 'win32') {
    const winSpec = toNodeImportSpecifier('C:\\Program Files\\App\\loader.mjs');
    assert.equal(winSpec, 'file:///C:/Program%20Files/App/loader.mjs');
  } else {
    const posixSpec = toNodeImportSpecifier('/Applications/App/loader.mjs');
    assert.equal(posixSpec, 'file:///Applications/App/loader.mjs');
  }
});

test('operator gets an absolute payload from the app resources when one is staged', (t) => {
  // Given a staged payload carrying runtime.json inside the app runtime resources
  const resources = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-primary-app-'));
  t.after(() => fs.rmSync(resources, { recursive: true, force: true }));
  const runtimeRoot = path.join(resources, 'runtime');
  const payload = path.join(runtimeRoot, 'primary-runtime');
  fs.mkdirSync(payload, { recursive: true });
  fs.writeFileSync(path.join(payload, 'runtime.json'), '{}');

  // When the primary runtime is resolved
  const resolved = resolvePrimaryRuntime(runtimeRoot, path.join(resources, 'home'));

  // Then the staged directory is returned.
  assert.equal(resolved, payload);
});

test('operator falls back to the trading home payload when the app stages none', (t) => {
  // Given no app payload but a home payload under dsh-runtimes/dsh-primary-runtime
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-primary-home-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const home = path.join(root, 'home');
  const payload = path.join(home, 'dsh-runtimes', 'dsh-primary-runtime');
  fs.mkdirSync(payload, { recursive: true });
  fs.writeFileSync(path.join(payload, 'runtime.json'), '{}');

  // When the primary runtime is resolved
  const resolved = resolvePrimaryRuntime(path.join(root, 'runtime'), home);

  // Then the home payload is returned.
  assert.equal(resolved, payload);
});

test('operator keeps the capability absent when no payload carries runtime.json', (t) => {
  // Given an app directory and a home directory without a valid payload
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-primary-none-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const home = path.join(root, 'home');
  const empty = path.join(root, 'runtime', 'primary-runtime');
  fs.mkdirSync(empty, { recursive: true });
  fs.writeFileSync(path.join(empty, 'not-runtime.json'), '{}');

  // When the primary runtime is resolved
  const resolved = resolvePrimaryRuntime(path.join(root, 'runtime'), home);

  // Then nothing is returned: the rows stay explicitly disabled and never fall back to a system Python.
  assert.equal(resolved, undefined);
});

test('operator never reaches across to the host ~/.dsh payload', (t) => {
  // Given a home whose sibling dsh home holds a payload (the host instance)
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-primary-cross-'));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const home = path.join(root, 'home', '.dsh-trading');
  const hostPayload = path.join(root, 'home', '.dsh', 'dsh-runtimes', 'dsh-primary-runtime');
  fs.mkdirSync(hostPayload, { recursive: true });
  fs.writeFileSync(path.join(hostPayload, 'runtime.json'), '{}');

  // When the primary runtime is resolved for the trading home
  const resolved = resolvePrimaryRuntime(path.join(root, 'runtime'), home);

  // Then the cross-home payload is not used.
  assert.equal(resolved, undefined);
});
