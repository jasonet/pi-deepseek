# Agent Note: Windows 兼容遗留项整改——.gitattributes 强制 LF 与 CI 矩阵加固

Status: implemented

## Problem

2026-09-06 的 Windows 兼容性盘点（会话调查结论）确认桌面安装包已可独立运行、
CI 实证全绿，但存在四类遗留债：

1. **仓库无 `.gitattributes`**——CRLF 是整类地雷而非已根治：v0.1.4 的
   bundle preset 行定位事故（见同日 bug-fix note）只做了代码级
   `replace(/\r\n/g, '\n')` 归一，今后任何新代码再对检出的 asset 做
   LF 锚定搜索，Windows runner（autocrlf）上必然复发。
2. **Windows 测试只在发版窗口跑**——ci.yml 仅 ubuntu runner，Windows 信号
   只出现在推 tag 时：v0.1.2（chmod 语义、installer.nsh 编码）与
   v0.1.4（CRLF 行定位）两次故障都是发版当天才暴露、靠删 tag 重推救回。
3. **nsis.include 侥幸路径**——`include: resources/installer.nsh` 的主解析
   必失（buildResources 相对拼接成 `resources/resources/installer.nsh`），
   一直靠 app-builder-lib `getResource` 的 projectDir 回退命中
   （2026-09-05 windows-nsis-ifexists-and-encoding note 自标的遗留项）。
4. **未验证项**：Windows 真实文件占用的 updater 锁集成测试未补（同 note
   后续项）。

## Decision

1. **根级 `.gitattributes` 统一 LF**：
   - `* text=auto eol=lf`——所有文本文件在所有平台检出恒为 LF，根除
     autocrlf 检出差异；
   - `spikes/** -text`——spikes 下的原始响应证据（headers/body/html）
     字节保真，绝不做行尾转换（现网 18 个 i/crlf 文件全在此目录，
     归一等于篡改证据）；
   - `*.bat` / `*.cmd` 例外 CRLF（Windows 命令解释器消费）。
   - 实施核验：索引内除 spikes 外全部本就是 `i/lf`，加属性后
     `git status` 零扰动，无需 renormalize 提交。
2. **ci.yml 加 windows-latest 矩阵项**：`include` 矩阵 = ubuntu×(node 22,24)
   + windows×(node 22)，Windows entry 与 desktop-release 管线同源
   （`pnpm install --frozen-lockfile` + `pnpm -r build` + `pnpm -r test`）。
   typecheck-gate 与 i18n 门禁是平台无关的 lint 级闸门，ubuntu 双节点已
   覆盖，Windows 不重复跑以控时长（`if: matrix.os == 'ubuntu-latest'`）。
   node 钉 22 与发版管线 setup-node 一致。
3. **electron-builder.yml `nsis.include` 改纯文件名 `installer.nsh`**：
   app-builder-lib `getResource(custom, "installer.nsh")` 对非空 custom 的
   解析顺序 = buildResources 目录清单命中 → `resolve(resourcesDir, custom)`
   → `resolve(projectDir, custom)` → 抛错。纯文件名走第一主路径确定性命中
   `desktop/resources/installer.nsh`；且今后路径写错会立即抛
   InvalidConfigurationError 而非静默侥幸。

## Verification

- `.gitattributes`：`git ls-files --eol` 确认 spikes 显示 `attr/-text` 且
  内容保持 `i/crlf` 原样；加属性后 `git status` 无任何行尾引起的改动。
- `nsis.include`：本地 macOS 交叉构建
  `npx electron-builder --win nsis --x64 --publish never` 完整通过，产出
  `dsh-trading-desktop-0.1.4-win-x64.exe`（getResource 找不到文件会直接
  抛 InvalidConfigurationError，构建通过即证明主路径解析命中）。
- ci.yml 矩阵：提交 push 后首个 ci run 即含 windows-latest job，以该 run
  全绿为最终验收（见本 note 收尾时的 run 记录）。

## Consequences

- Windows 专属故障的暴露点从「发版窗口」前移到「每个 push/PR」，
  删 tag 重推的发版救火模式不再为 CI 盲区买单。
- **该前移有一个实测边界（2026-10-09 补）**：`pnpm -r test` 遇首个失败包即
  中止（`ERR_PNPM_RECURSIVE_RUN_FIRST_FAIL`），所以只要矩阵里排在前面任意一包
  长期判红，其后所有包的 Windows 信号就**全部不被观测**——「前移到每个 push」
  只对「排在首个失败包之前」的包成立。v0.6.0 正是这样：`@dshtrading/dsh-home`
  一直先红，把排在其后的 `@dshtrading/authority` 整段遮住，后者从上线起
  从未在 Windows 上执行过，直到 dsh-home 修好才第一次暴露；修好 authority 又
  露出 `@dshtrading/base`。判读这条信号时必须同时确认该 run 是「跑完全部包」
  还是「中止在首个失败包」——只看 job 结论会把「未观测」误读成「通过」。
- 新增代码若再依赖「Windows 检出为 CRLF」的前提会直接失效——这正是目的，
  仓库从契约上锁死 LF。
- `desktop/dist` 本地产物由本次交叉构建刷新为 0.1.4-win-x64（含新
  installer.nsh 解析路径）。

## 遗留（明确不在本轮处理）

- **Windows arm64 构建**：产品级决策（fetch-node TARGETS、builder 矩阵、
  verify-toolchain 均需扩），成本是每版 +一份产物与构建时长，待用户拍板。
- **代码签名**：需付费证书，维持未签名 + 安装引导（release-preamble）现状。
- **Windows 真实锁集成测试**：Node/libuv 打开的句柄自带
  FILE_SHARE_DELETE，纯 JS 无法可靠模拟文件占用锁；windows 矩阵落地后
  具备了真实验证位，待后续窗口补。


## Alternatives considered

<!-- agent-note-format: alternatives-not-recorded (pre-format Agent Note) -->

## Windows 保留设备名（2026-10-21 补）

- **故障**：`packages/indicators` 在 2026-10-12（`66c612cd`）引入 `src/aux.ts` 与
  `test/aux.test.ts`。`AUX` 是 Windows 保留设备名，windows-latest 的
  `actions/checkout` 直接失败 `error: invalid path 'packages/indicators/src/aux.ts'`
  （git 退出 128），`pnpm install` 与测试步骤全部 skipped —— 失败发生在读任何代码之前。
  最近五个已完成的 ci run（`39562570170` / `39589273130` / `39590403812` /
  `39591597082` / `39592536042`）windows job 的失败步骤都是 `Run actions/checkout@v4`。
  ubuntu 侧静态门禁与单测全绿，这类故障只有 windows-latest 能暴露。
- **处置**：模块改名 `aux.ts` → `aux-series.ts`（测试同步 `aux-series.test.ts`），
  包内三处 `./aux.ts` 导入与文档注释一并改；`@dshtrading/indicators` 的 exports 只有
  `.` / `./tool` / `./plugin` / `./package.json`，`aux` 从不是公开子路径，
  消费方按文件路径引用零命中，改名对外零影响。否决的方案：`.gitattributes` 与
  `core.protectNTFS` 只影响 NTFS 检查、不会重命名文件；sparse-checkout 排除该路径等于
  把模块从 Windows 构建里删掉。
- **规则**：受跟踪文件与包产物不得使用 Windows 保留设备名（`CON` `PRN` `AUX` `NUL`
  `COM1..9` `LPT1..9`，含带扩展名形式），也不得以空格或点结尾。这条不只约束 checkout：
  桌面壳 `prepare-runtime` 把 workspace 包打成 tarball 再解包，同一批名字在 Windows 上
  解包同样失败，而 `desktop-release` 是 all-or-nothing（windows 打包失败即 Release
  不创建，npm 却可能已经发出去）。
- **下一层（同日）**：checkout 修好后 windows 矩阵才第一次跑到 `pnpm -r test`，立刻露出
  `packages/connector-polymarket/test/snapshot.test.ts:63` 把期望值写死为
  `/tmp/dsh-trading-home/polymarket/snapshots.json`（Windows 上是
  `D:\tmp\dsh-trading-home\…`，`ERR_PNPM_RECURSIVE_RUN_FIRST_FAIL` 中止整轮）。
  修法沿用本页既有口径——期望值按本平台算：`join(resolve('/tmp/…'), 'polymarket', 'snapshots.json')`。
  读这条时同时记住上节的遮断边界：checkout 一红十年，`-r test` 里排在它后面的包在
  Windows 上根本没被执行过。
- **再下一层（同日）**：`pnpm -r test` 走到 `packages/bot-api` 时，`tasks-tools` 与
  `tasks-bridge` 两个用例文件在 afterEach 里 `rmSync` 临时目录报
  `EBUSY: resource busy or locked`——账本的 `*.writer-lease.sqlite` 还开着。
  POSIX 允许删除被打开的文件，所以本机与 ubuntu 从不暴露，只有 Windows 会。
  修法是把 dispose 放回用例：`tasks-tools` 收集 service 并在 afterEach 先 dispose；
  `tasks-bridge` 的假 ctx 原本把 effect 返回的清理函数丢掉（`effect: (fn) => { fn() }`），
  现在收集后由 afterEach 执行。写新用例时先问一句「这个资源谁在 Windows 上关」——
  文件锁、SQLite 句柄、临时目录三件事在 POSIX 上都会自己消失，在 Windows 上不会。
- **同类的最后一层（同日）**：`packages/bot-api/test/setup.ts` 的 afterAll 也要删那个全局
  临时目录，而其余用例文件仍靠伪 ctx 丢掉清理函数、账本 lease 开着。那里**不**逐个改
  二十个用例文件：afterAll 只吞 Windows 的 `EBUSY`/`EPERM`（断言对象是账本语义，不是临时
  目录回收），其余错误照旧抛。`test:audit` 的零 sleep 口径下也不能用重试等待。

