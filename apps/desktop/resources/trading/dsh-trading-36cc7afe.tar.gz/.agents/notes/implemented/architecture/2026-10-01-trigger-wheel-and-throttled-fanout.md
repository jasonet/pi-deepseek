# 触发器与扇出：持久 timer wheel、补算错过、节流扇出

日期：2026-10-01 · 阶段：P3 步骤 3 · 卡片：317a623f · 包：`@dshtrading/tradectl/triggers`

## 事实

- **核心自建，不依赖官方 schedule/webhook**：触发必须与账本同生共死，而不是寄居在一个可以被单独重启/升级的宿主插件里。
- **调度表与 occurrence 都落在 orders.db**（`synchronous = FULL`，与钱同一个耐久档）：错过的触发是风险相关事实，静默丢掉它就是"该减的风险没减"。occurrence 主键 `(scheduleId, dueAtMs)` 天然幂等——同一个触发点重复触发不是新事件。
- **`dueOccurrences` 是唯一的触发入口**：重启后的第一次调用就是"补算错过"，没有第二条捷径可以绕过它。
- **错过只能减风险**：错过的 occurrence 带 `missed` 标记，整批以 `reduceOnly: true` 扇出。理由：错过的开仓信号**不能**补执行（价格早变了），错过的风控/减仓信号**必须**补上。
- **节流扇出**：`followup` 每次都是一条独立普通 turn（官方语义），窗口内最多扇 `maxPerWindow` 条，多出来的**合并进同一条**并带上完整 occurrences 与"合并了几条"的文本——**合并不等于丢**，丢才是问题。
- **扇出失败不吞**：返回 `failed` 并把 occurrence 记为 `failed`（可查、可重试、attempts 递增）。
- **换代只换 sessionId**：wheel 不持有任何会话状态，权威态在账本，所以 desk 会话换代后新会话从账本继续。
- **tick 的顺序是先记账后推进 nextAt**：崩在中间最坏是重复扇出一次（幂等兜住），而不是静默少扇一次——两种失败的代价不对称。

## 测试（10 例新增，tradectl 累计 83 例全绿）

未到点/到点/下一周期各一次；**重启错过 5 条全部以 missed 出现且整批 reduceOnly**；同一触发点不重复扇出；窗口内 6 条合并成 1 条且一条不丢；扇出失败如实记 failed；换代后新会话拿到新触发且账本留痕（权威态不在会话）；markFired 幂等（重复标记只增 attempts）；advanceSchedule 跳过中间点、一次性调度自我禁用；禁用调度不触发；扇出文本内容。真 `node:sqlite` + 注入时钟 + 契约假 followup，无 mock 无 sleep。


## 事件泵：进程内驱动（2026-10-01 补完 P3 步骤 3 的缺口）

`packages/tradectl/src/pump.ts`：把「到点判定 → 扇出 → 记账 → 排下一次」跑起来。此前 `dueOccurrences` / `markFired` / `advanceSchedule` 都只是零件，**没有任何东西在推动它们**（只在测试里被手动 tick 过）。

三条立场：

1. **不重造策略**：泵只做推进与记账，扇出交给注入的 `dispatch`（生产传 `createThrottledFanout(...).send`）。"错过是否降级为 reduce_only"属于触发器策略，泵不重复判断 —— 一个事实一个家。
2. **调度器可注入**（与 ws-feed 同一套做法）：测试里"等 30 秒"变成"取出回调来跑"，因此无 sleep。
3. **单次失败不许停机**：扇出抛错时留痕并继续排下一次 —— 泵在第一次网络抖动后静默停摆是最危险的故障（界面一切正常，触发器再也不响）。

### 实现里被测试抓出的一个真缺陷（已修）

第一版**扇出失败时只记 failed、没有推进排期** ⇒ 那条 occurrence 永远停在"已失败"，且 `nextAt` 留在过去：既不会重试（`dueOccurrences` 跳过已记录的 `due_at`），也走不到下一个间隔 —— **触发器从此静默停摆**，而账面上只有一条 failed。修法：失败同样 `advanceSchedule`，语义变成"这一次算失败并留痕（不静默消失），下一次按原节奏继续"。

### 一个性能事实（值得记，改不改等你定）

写测试时我第一版夹具把 `nextAtMs` 设成 0（落后约 3.4 亿个间隔），单个用例跑了 **363 秒**：`dueOccurrences` 每轮按 guard 上限吐 **1000 条** missed，每条一次 SELECT + INSERT，在 WAL + `synchronous=FULL` 下逐个落盘。

**这意味着一个真实风险**：机器停机很久后重启，一个间隔较短的调度会产生成百上千条 missed，泵要逐条写上千次事务才能追上。当前设计**没有"折叠积压"**这一步。

**我的建议（未做，需你定）**：给 `dueOccurrences` 加折叠 —— 同一调度落后超过一个间隔时，只产出**一条** missed（`dueAtMs` 取最近的过去点），并在记录里带上"跳过了 N 次"。这与卡片要求一致（"错过不得静默消失"：跳过次数要记账；"错过只能减风险"：仍然走 reduce_only 路径），而且把最坏情况从 O(积压) 降到 O(调度数)。**代价**：`dueOccurrences` 的语义变化会影响既有 10 条触发器测试（需同批更新）。因为这动的是核心触发器语义、且有既有测试依赖，我不自行改。


## 积压折叠：可选开关（2026-10-01 补，默认关闭）

`dueOccurrences(db, nowMs, options?` 新增 `collapseMissedBeyond`：某个调度落后超过 N 个间隔时，**只产出一条** occurrence（`dueAtMs` 取最近的过去格点），并把跳过的次数写进 `skipped`。

**默认关闭是刻意的**：它改的是**核心触发器语义**，是否启用属于判断（而不是"显然该做"）—— 所以这一轮只把开关与证据备好，默认行为**逐字未变**（既有 10 条触发器测试原样通过）。

**为什么需要它**（实测数字）：写事件泵测试时，夹具落后约 3.4 亿个间隔，单条用例跑了 **363 秒** —— `dueOccurrences` 每轮按 guard 上限吐 1000 条 missed，每条一次 SELECT + INSERT，在 WAL + `synchronous=FULL` 下逐个落盘。**机器长时间停机后重启会真的遇到这个积压**。折叠把最坏情况从 **O(积压)** 降到 **O(调度数)**。

**为什么不违背"错过不得静默消失"**：折叠产出的那一条带着 `skipped` 计数（跳过了几次如实记账），且仍然 `missed: true` 走减风险路径。**折叠本身若不记账，才会变成静默丢失** —— 这条写进了 Occurrence 的字段注释。

**测试 4 例**：启用折叠时落后 100 个间隔只出一条且 `skipped === 100`；不启用时保持既有语义（逐条、无 skipped 字段）；一次性调度（`intervalMs: null`）不受折叠影响；折叠结果幂等（记过账后不再重复产出）。

### 顺带修正：事件泵测试的库选错了

`migrateTriggers` 按本仓约定挂在 **orders** 库上（audit 是审计流），而我最初把事件泵测试接到了 audit —— 测试能过（表建在哪里都能用），但**示范了错误的接法**。已改为 orders，并加了一行注释说明约定。

## 进程入口：泵真的被一个进程启动了（2026-10-02 补，P5 步骤 1）

`packages/tradectl/bin/core.mjs` 是执行核的进程入口：启动断言（四条禁止的降级 + 两套词汇不相交）→ 带外 kill 闸门（production 形态必填 `--kill-state`，被杀/暂停即拒绝启动）→ **组装 `createDeskProcess`**（环路 + 事件泵 + dry-run 派发 + 积压告警入审计）→（可选）绑 UDS 并**周期调度 `checkIdentity`**（inode 被换 ⇒ 冻结 ⇒ 停机且不重绑）。

- **派发语义只有 dry-run**：入口不构造任何 venue 端口，`--mode=paper|live` 当场拒绝（退出码 2）——"没有下单路径"是装配出来的事实，不是纪律承诺。
- **泵的驱动换成真实调度器**：`setTimeout` 按 `--interval-ms` 推进，不再是"只在测试里手工 tick"；积压阈值经 `--backlog-warn-threshold` 转交泵的 `onBacklog` ⇒ `trigger.backlog` 进审计（runbook「待接线」第 1 件事落地）。
- **复现**：`node packages/tradectl/bin/core.mjs --home=<dir> --seed-demo-schedules --run-ms=1500 --interval-ms=200 --backlog-warn-threshold=2`（退出码即断言）；测试 `test/desk-entry.test.ts` 5 例含 SIGTERM 优雅退出。
- **仍然没做**：与官方 `ctx.agents.get(deskSessionId).followup(...)` 的真实扇出（入口的 dispatch 是 dry-run 记账，真实接线仍落在 bot 宿主进程）；积压折叠开关仍默认关闭。

## 未验证项（如实标注）

- **与官方 `ctx.agents.get(deskSessionId).followup(...)` 的真实接线未做**：本轮实现的是扇出端口（`FanoutPort`）与节流器，测试用注入的 followup。真实接线要在 bot 宿主进程里落地，属步骤 5（shadow 跑批）的前置。
- ~~**timer wheel 的驱动频率与 tick 的真实定时器未接**~~（2026-10-02 已接：进程入口按 interval 起真实 `setTimeout`，见上一节）。
- **调度表的写入面（谁加调度）未定**：本轮只有 `addSchedule`，编排来源（mandate/风控/宏观日历）属后续步骤；入口只在 `--seed-demo-schedules`（演示开关）下种调度，不在生产路径上造调度。

## 被否决的方案

- **用官方 schedule/webhook 插件**：卡片明确要求核心自建；而且触发与账本必须同生共死（宿主可被单独重启/升级）。
- **occurrence 只记在内存**：重启即丢，正是卡片禁止的"静默消失"。
- **扇出超限就丢弃**：桌面会话被刷爆是问题，丢触发是更大的问题；改成合并。
- **错过的触发按原语义补执行**：错过的开仓信号补执行等于用一个过期的判断去开新仓。

## gap report 收集器（2026-10-01 补，P5 步骤 1 第二根线）

`packages/tractectl`… 更正：`packages/tradectl/src/gap-collector.ts` 的 `collectGapReport({orders, audit}, window)`：能从库里取的就取，**取不到的逐条点名**（`missingInputs`）—— 不用空数组冒充"期间什么都没发生"，后者是最危险的谎。

**实测出来的数据源完整度**（四类里只有一类齐全）：

| 输入 | 数据源 | 状态 |
|---|---|---|
| 错过的触发 | `occurrences.missed` + `due_at_ms` | ✅ 齐全 |
| 被拒意图 | `intents.state = 'rejected'` | ⚠️ 能数条数，**没有理由列** |
| 降级动作 | journal 的 `degradation*` 事件 | ⚠️ **没有写入点**（现有写入点是 shadow.decision 与 reconcile.*） |
| 持仓变化 | `positions` | ⚠️ **只有当前值、无历史** ⇒ 只能给"之后" |

**这条发现改变了工作量判断**：让"恢复必须产出 gap report"成立，不是接一根线，而是要先补三处**记录** —— 而这三处记录本身就是审计要求（被拒理由、降级动作、持仓变化都该留痕）。

测试 4 例（真 node:sqlite + 真表结构）：missed 触发能取到并带到点时间；空窗口时报告为空但**缺口清单不为空**；被拒意图给条数并说明理由取不到；窗口边界是闭区间。
