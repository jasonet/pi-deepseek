# Agent Note: 实盘交易打通、专业终端布局重构与上市公司公告修复

Status: implemented

## Problem

用户在体验交易平台时反馈了四个关键问题：
1. **“只做真交易，不做假交易”**：原 GUI 交易台强制 `dryRun: true`，且各处提示“Dry-Run 模拟 (GUI 不提供实盘通道)”，违背了用户对真实交易执行通道的核心预期；
2. **“另外UI设计位置是不是不对”**：原有交易工作台横向塞在 K 线图左下角，把主 K 线图视野严重压缩，且持仓、委托、流水三个宽表格挤在狭小的角落，文字换行重叠截断，严重不符合看盘下单的人体工学；
3. **“还有公告怎么是空的，获取不到吗”**：个股（如中国平安 601318、贵州茅台 600519）的「公告」页签常年为空；
4. **交易与衍生品局部视觉问题**：OrderPanel 下单按钮宽度坍塌（只占左侧 40%），加密货币单位显示“0 股/份”；DerivativesPane 横卡在主图与 X 轴时间刻度之间遮挡时间轴；
5. **“不应该搜出不存在的股票”**：输入未确认的 6 位数字代码（如 `000283`）时，搜索下拉框居然盲目搜出 `000283.SZ 000283 (A股)`，点进去因为深交所根本不存在该股票而导致拉取 K 线 404 报错。

## Decision

### 1. 彻底实现真交易（清除假交易模拟）
- `packages/bot-api/src/bridge.ts`（2026-10-01 从 client-ui-trading 搬包）：`placeOrderFromGui` 移除硬编码 `dryRun: true`，默认执行 `dryRun: false` 实盘报单，直接贯通底层连接器的真实网络下单能力；
- `api.ts` 与错误回执：若连接器未配置 API 凭证或未开启 `liveTrading`，如实向上抛出错误原因（如未配置密钥、未开启实盘），并在 UI 提供明确提示，绝不伪造虚假成交；
- 全面清理多语言文案：移除所有 `dryRun` 占位和模拟提示，切换为“实盘通道”、“立即下单”、“报单成功”等真实交易语义。
- **2026-10-12 用户裁决：保留 GUI 实盘，接入官方逐动作审批**。GUI 的实盘路径（`POST/DELETE /trade/order`）经 `packages/bot-api/src/gui-approval.ts` 调用宿主真实 `ctx.approval.request`（`@deepseek-ai/dsh-user-approval` 的 `ApprovalService`），只认 `allowed-once`：
  - 审批绑定**实际 agent/session**：客户端（`QuotePane` 经官方 `useSessions` + `currentSessionId`）传当前主视图会话 id，宿主用 `agents.get(sessionId)` 解析 agent 并以 `agent.session.id` 复核，串会话一律拒绝；`ctx.approval` 缺席、会话缺席、拒绝、取消、HTTP 断连（AbortSignal）全部 fail-closed 到 `TRADING_APPROVAL_DENIED`——绝不退化成模拟单，不伪造 dry-run 回执；`ApprovalService` 的审计对 `approval/asked`/`approval/decided` 落在该会话日志里；
  - **空闲会话可用（2026-10-12 二次修复）**：`request()` 的硬前置是「会话日志存在未关闭的一轮」（审计对必须 turn-enclosed），而开轮的权力只在官方 agent-loop 内。GUI 座位因此声明自有消息 source、等目标 agent 空闲后用 `agent.send` 唤起一轮，在 `agent/pre-step` 里就地在轮内 `await ctx.approval.request(...)` 后返回 `{kind:'reject'}`——得到有 `turn/start..turn/end`、**无** `step/start`、无 `user/message`、无模型请求的官方轮次（实现与三个边界见 `packages/bot-api/src/gui-approval.ts`；用例读真实事件 seq 断言审计对夹在该轮内）。**代价**：每笔 GUI 实盘动作在该会话日志留下一个空的持久 turn；等待空闲的窗口默认 30s，超时 fail-closed 可重试；
  - 展示与绑定同源：`reason` 带完整规范化快照（market/symbol/side/type/quantity/price/intentId/sessionId；撤单为 market/orderId/symbol/intentId/sessionId），工具名沿用 base 闸门词汇（`<market>_place_order`/`<market>_cancel_order`），GUI 动作与 agent 工具动作在审计里同口径；
  - 所有实盘调用带**稳定意图 id**（客户端 UUID）：未知结果/网络失败重试续用同一 `intentId`，参数变化、成功或主动新意图才换；撤单与下单同门槛；
  - 文案已对齐实现（2026-10-12）：`trade.liveHint`（`packages/client-ui-trading/src/client/locales.ts`）写明「本面板可发起实盘下单：每次提交先在当前会话弹出逐动作审批，通过后仍需连接器已获人工签署的实盘授权；审批被拒或不可用时明确失败，不会退化成模拟成交」。

### 2. UI 专业终端布局重构（对齐富途牛牛/同花顺/TradingView）
- **右侧盯盘下单侧边栏（`OrderPanel`）**：
  - 将快速下单面板移至右侧，与五档盘口（`OrderbookPane`）上下垂直整合；
  - 用户边盯盘口买卖档位与逐笔成交，边在下方一键买入/卖出；点击盘口档位价格可直接联动填入下单价格；
  - 彻底释放中间主图，K 线图拥有 100% 完整的高度和开阔视野；
  - 下单按钮 100% 全宽拉满，饱满质感，买入明亮正绿/正红，卖出反色；
  - 增加自适应资产单位（Crypto 显示对应代币如 ETH/BTC，股票显示股）；
  - 增设 `25%` / `50%` / `75%` / `100%` 仓位比例快捷填单胶囊；限价模式即时计算成交预估金额；
- **底部全宽资产与委托抽屉（`TradeDrawer`）**：
  - 将当前持仓、活动委托、成交历史与账户资金重构为底部全宽（100% 宽度）抽屉；
  - 默认状态为 28px 的微状态栏（展示持仓与活动委托数字 Badge，不遮挡图表）；点击任意 Tab 即可平滑展开至 160px 大表格，所有列平铺舒展；
  - 活动委托表格内嵌「撤单」操作按钮与加载态防重。

### 3. 上市公司公告获取修复（解决空列表）
- **修复致命裁切 Bug**：在 `bridge.ts` 的 `news()` 方法中，修复了因个股 24h 内无媒体快讯触发大盘要闻回退时，使用 `[...macro, ...items].slice(0, 20)` 误将时间较早的上市公司官方公告截断裁掉的致命缺陷；将标的官方公告列为最高优先级无条件完整保留；
- **放宽公告时间窗**：在 `packages/kit-cn/src/news.ts` 和 `packages/kit-hk/src/news.ts` 中，将上市公司公告最大展示窗口从 7 天放宽至 90 天（满足上市公司低频法定披露特性）。修复后，中国平安的权益分派实施公告、贵州茅台的半年度报告等 10+ 条官方公告立即在「公告」页签完整呈现。

### 4. 衍生品指标条重构（彻底释放主图视线）
- 将 `DerivativesPane` 彻底移出主图下沿，彻底解决横跨遮挡 X 轴时间刻度的问题；
- 重构为轻量级微型指标组，嵌入顶部行情统计栏（昨收/今开/高/低/量的右侧），支持 Hover 详细说明与红绿联动，保持图表极致纯净。

### 5. 根除幽灵假股票盲目推造（严格真实收录）
- **根因分析**：原 `packages/router/src/catalog.ts` 的 `searchSymbols` 与 `searchAllMarkets` 中内置了硬编码正则，只要输入 6 位数字无论真假一律暴力拼接成 `${code} (A股)`。当输入深交所未分配代码 `000283` 时，直接捏造幽灵标的推入下拉框，导致用户点击后进入 404 报错页面；
- **治理决策**：
  1. 彻底删除 `catalog.ts` 中针对 6 位数字的盲目正则推导，搜索联想严守真实收录原则；
  2. `bridge.ts` 的 `/symbols` 端点支持 `query` 参数并直通各市场连接器的 `listInstruments(query)`（如东财官方在线联想）；
  3. `MarketSidebar.tsx` 对用户输入采用防抖真实在线查询：搜 `000938` 时精准返回上游权威确认的 `000938.SZ 紫光股份` 并动态入库；搜 `000283` 时上游返回空，下拉框坚决不返回任何假代码，从源头绝杜绝无效代码进入。

## Verification & Gates

- 真实网络验证：Node 真实脚本调用 `bridge.news('cn', '601318', '20')` 成功返回 19 条中国平安官方公告；`600519` 成功返回 14 条贵州茅台官方公告；
- 真实股票与假股票搜索验证：东财 suggest 与 bridge.symbols 检索 `000938` 精准返回紫光股份，检索 `000283` 返回空数组；
- 单测验证：`pnpm test` 全仓 103 个测试套件、738 个测试用例 100% 绿灯全过；
- 构建验证：`pnpm build` 全仓 28 个 package 全部构建成功。


## Alternatives considered

<!-- agent-note-format: alternatives-not-recorded (pre-format Agent Note) -->

## Consequences

- 实盘通道与专业看盘布局全面打通，个股公告数据流恢复正常；
- 改善了看盘下单的人体工学与交互体验。
