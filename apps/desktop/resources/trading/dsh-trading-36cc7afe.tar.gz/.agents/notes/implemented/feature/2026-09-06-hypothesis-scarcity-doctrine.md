# Agent Note: 预设方法论铁律——假设闭环、禁用评级/目标价、稀缺性预期

Status: implemented

## Problem

统一角色预设（[2026-09-06-unified-trading-role-presets.md](../architecture/2026-09-06-unified-trading-role-presets.md)）的人设只有证据纪律与执行闸门，缺交易方法论内核：允许「预测式」口吻，未禁止引用分析师评级与机构目标价，也没有回答「为什么持有这个标的」。owner 定调：成熟交易员从不预测市场，只提出假设并观察验证、按假设制定计划与双向预案；分析不参考评级与所谓目标价，要深挖核心持有逻辑与未来预期；交易对象是「标的稀缺性的预期」（买预期、卖现实）。

## Decision

在 `packages/base/src/presets.ts` 新增共享常量 `DOCTRINE`（方法论铁律三条），注入全部四角色 persona 与三个委派子代理 persona（composePresets 统一拼接，位于角色文本与 EVIDENCE 之间）：

1. **不预测，只假设**：一句话可证伪假设 + 双向预案（符合/不符合分别怎么做、退出后何时可重新进场）+ 持续验证；走势证伪假设时第一动作是停止旧策略，禁止换理由硬扛；假设与失效条件没写出来不谈买卖，符合假设不自动加仓。
2. **不引用卖方评级与目标价**：评级/目标价不构成依据、不作结论支撑；机构一致盈利预期仅作「市场当前定价了什么预期」的坐标并标注数据日期。
3. **交易对象是稀缺性预期**：先挖核心持有逻辑（稀缺性来源），再判预期定价档位；买预期、卖现实，先分清价格反映过去/现在/未来。

角色专属修订：交易员——计划必须带双向预案与重新进场条件，信号失效不得临时换模式硬扛；研究员——主责改为挖透核心持有逻辑（稀缺性来源与预期定价阶段），交付多情景假设（各带验证/失效信号），roster description 同步；风险审查员——审查范围扩到假设本身（可证伪性、失效条件可执行性、预案双向完整性、是否隐性依赖评级/目标价）；大师——委派任务书携带「要验证的假设与失效信号」，整合交付按事实/假设/预案三层组织。

随包技能同步：`company-analysis`（SKILL.md 与扁平副本保持逐字节一致）防污染规则升级为评级/目标价禁令，新增「核心持有逻辑与稀缺性预期」章节（估值前先答稀缺性来源与预期定价档位；不写目标价预测，只写情景估值区间与市值反推的隐含假设），八大模块综合判断与综合结论表、HTML 报告结构第 8 节同步加字段；`crypto-instrument-analysis` 结论改为假设式输出（核心假设+验证信号+失效信号），第五步新增稀缺性核验（供给上限/减半/销毁/解锁），禁止事项加预测式表述禁令。

方法论内容与 cowork 交易日志同源：`trading_journal/rules/mid_long_term_hypothesis_loop.md`（假设闭环与双向预案）、`fundamental_analysis_framework.md`（买预期卖现实三模式、预期定价阶段）、`market_cognition_three_money_sources.md`（共识/故事视角下评级与目标价是他者预期噪音）。

## Alternatives considered

把方法论做成独立 bundled skill 随包分发：人设层仍需一句稳定信条才能保证所有角色（含 fork 子代理）默认遵守，skill 适合承载细节而非铁律本身——选择「DOCTRINE 常量进人设 + 细节进既有分析 skill」；未来若铁律膨胀再抽 skill。回写四个市场旧资产文件（`packages/*/assets/preset/*-trader/`）的人设段：该段自统一角色起即为死内容（`getPresetContribution()` 只切 connector 行起点的能力行，旧预设目录由安装器归档），改动徒增 diff——不改。把机构一致预期也一并禁用：一致盈利预期是「市场已定价什么」的必要坐标（买预期卖现实必须先知道预期），只禁评级/目标价这类无信息量结论——保留坐标用法并强制标注数据日期。

## Consequences

`presets.test.ts` 断言锚点现为英文等价串（全部预设含 `Never predict` / `Never cite sell-side ratings or target prices` / `scarcity`，master 另含 `hypotheses to verify with invalidation signals`；2026-09-06 晚注入文本统一英文，见 [2026-09-06-english-persona-unification.md](2026-09-06-english-persona-unification.md)）。base 27 例、kit-crypto 23 例全绿，两包 tsdown 构建通过；生成态 master persona 目检确认共享常量拼接顺序（角色文本 → DOCTRINE → EVIDENCE → JOURNAL → 市场清单）。（2026-09-16 修订：`EVIDENCE` 与 `JOURNAL` 之间新增 `VERDICT` 证据契约常量，见 [2026-09-16-evidence-contract-convergence.md](../process/2026-09-16-evidence-contract-convergence.md)。）persona 变长约 400 字/角色，属 Layer 1 静态前缀，稳定后不损害 KV Cache；DOCTRINE 文本后续改动应整段替换、避免逐句漂移。生效路径不变：宿主重启后 base 安装器幂等重写托管预设（管理戳保护用户自定义副本）；运行中会话不热更。旧四市场资产文件保持原样，其死内容人设段若未来清理属 simplification。
