'use strict';

/**
 * DeepSeek Harness desktop — Electron main process.
 *
 * The app owns one dsh host child process: it seeds $DSH_HOME/profiles/
 * trading-web from the bundled profile when needed, spawns the bundled Node
 * runtime on a free loopback port, waits for the GUI, and loads the tokenized
 * URL the host prints. The app always starts its own host: a probe cannot
 * tell which profile an already-running GUI serves, so attaching to one would
 * hand off to an unrelated instance (this bug shipped once — the probe hit a
 * plain web GUI on port 3080 and the app opened the user's own DSH Web).
 */

const { app, BrowserWindow, ipcMain, shell } = require('electron');
const { spawn, execFile } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {
  resolveRuntimePaths,
  selectDshHome,
  resolvePrimaryRuntime,
  readStampFile,
  runtimeSeedStamp,
  profileAction,
  applyProfileSeed,
  normalizeProfileCohort,
  findFreePort,
  waitForGui,
  waitForTokenUrl,
  createTokenUrlCollector,
  formatHostExitDiagnostic,
  formatHostExitLine,
  planHostRecovery,
  isNavigationFailureFor,
  HOST_RECOVERY_MAX,
  HOST_RECOVERY_WINDOW_MS,
  asarUnpackedPath,
  toNodeImportSpecifier,
  consoleMessageArgsToEntry,
  rendererLogLine,
} = require('./runtime.cjs');

const READY_TIMEOUT_MS = 180000;
const LOG_TAIL_LINES = 200;
/** Browser-session cookie the host issues for its own request authority. */
const AUTH_COOKIE_PREFIX = 'dsh-auth-';
/**
 * Request-header budget for the spawned host. The host serves the client
 * plugin batch as one combo URL (`/plugins/??<every client entry>&rev=…`,
 * measured 2.8 KiB), which Node's 16 KiB default leaves little room for.
 */
const MAX_HTTP_HEADER_BYTES = 65536;

/** @type {BrowserWindow | null} */
let mainWindow = null;
/** @type {import('node:child_process').ChildProcess | null} */
let hostChild = null;
let quitting = false;
let logStream = null;
/** Tokenized GUI URL of the current host; see createTokenUrlCollector. */
const bootUrls = createTokenUrlCollector();
/** True while one boot is in flight; see boot(). */
let booting = false;
/** Timestamps of host exits the shell did not ask for; see planHostRecovery. */
let unexpectedExitTimes = [];
/** Ring buffer of recent host output for the error page. */
const logTail = [];

function resourcesRoot() {
  return app.isPackaged ? process.resourcesPath : path.join(__dirname, '..', 'resources');
}

function logFilePath() {
  return path.join(app.getPath('logs'), 'dsh-host.log');
}

function pushLogLine(line) {
  logTail.push(line);
  if (logTail.length > LOG_TAIL_LINES) logTail.shift();
  if (logStream !== null) logStream.write(line + '\n');
  bootUrls.observe(line);
}

function setStatus(text) {
  if (mainWindow !== null && !mainWindow.isDestroyed()) mainWindow.webContents.send('desktop:status', text);
}

/**
 * Environment for the host child. `primaryRuntime` is supplied only when the
 * dependency payload actually exists on disk, so the Office and
 * workspace-dependency rows stay explicitly disabled (not silently replaced)
 * on an installation that carries no payload.
 * @param {string} home - Resolved DSH home.
 * @param {string} nodeHome - Bundled Node distribution root.
 * @param {string} [primaryRuntime] - Absolute payload directory, when one exists.
 */
function childEnv(home, nodeHome, primaryRuntime) {
  const env = { ...process.env, DSH_HOME: home };
  if (primaryRuntime !== undefined) env.DSH_PRIMARY_RUNTIME = primaryRuntime;
  // The host hooks watch this shell so a shell that dies without `before-quit`
  // (SIGTERM/SIGKILL to the app) does not leave the detached host orphaned;
  // see src/host-orphan-guard.mjs.
  env.DSH_DESKTOP_SHELL_PID = String(process.pid);
  // The bundled Node distribution comes first so anything the host shells out
  // to (npm, corepack) resolves against the bundled runtime, never the system.
  const nodeBinDir = process.platform === 'win32' ? nodeHome : path.join(nodeHome, 'bin');
  const currentPath = env.PATH || env.Path || '';
  env.PATH = nodeBinDir + path.delimiter + currentPath;
  if (process.platform === 'win32') {
    env.Path = env.PATH;
  }
  delete env.ELECTRON_RUN_AS_NODE;
  return env;
}

/**
 * Load hooks injected into the host with `--import`, in order.
 *
 * `host-symbol-normalizer.mjs` shares the dsh core's per-instance symbols across
 * package copies; `host-exit-tracer.mjs` records why the host left;
 * `host-orphan-guard.mjs` ends a host whose shell is gone. Each owns its own
 * module doc.
 */
const HOST_HOOKS = [
  'host-symbol-normalizer.mjs',
  'host-exit-tracer.mjs',
  'host-orphan-guard.mjs',
];

/**
 * On-disk path of one host load hook, or undefined when the packaging layout
 * does not provide it. electron-builder packs src/ into app.asar, but these
 * hooks are imported by the external bundled Node runtime, which cannot read
 * inside the archive — asarUnpack places them next to it as app.asar.unpacked/,
 * and development runs resolve unchanged.
 * @param {string} fileName
 * @returns {string | undefined}
 */
function hostHookPath(fileName) {
  const unpackedPath = asarUnpackedPath(path.join(__dirname, fileName));
  return fs.existsSync(unpackedPath) ? unpackedPath : undefined;
}

function startHost(runtime, home, port) {
  const primaryRuntime = resolvePrimaryRuntime(runtime.runtimeRoot, home);
  pushLogLine('[desktop] primary runtime: ' + (primaryRuntime ?? 'absent (Office skills and load_workspace_dependencies stay disabled)'));
  const hookImports = [];
  for (const hook of HOST_HOOKS) {
    const specifier = toNodeImportSpecifier(hostHookPath(hook));
    if (specifier === undefined) {
      pushLogLine('[desktop] host hook missing from the payload, spawning host without it: ' + hook);
      continue;
    }
    hookImports.push(specifier);
  }
  if (hookImports.length > 0) {
    pushLogLine('[desktop] injecting host hooks: ' + hookImports.join(' '));
  }
  const args = [
    '--max-http-header-size=' + String(MAX_HTTP_HEADER_BYTES),
    ...hookImports.flatMap((specifier) => ['--import', specifier]),
    runtime.hostBin, '--profile', 'trading-web', '--no-open', '--host', '127.0.0.1', '--port', String(port),
  ];
  const child = spawn(runtime.nodeBin, args, {
    cwd: home,
    env: childEnv(home, runtime.nodeHome, primaryRuntime),
    detached: process.platform !== 'win32',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  const onData = (chunk) => {
    for (const line of String(chunk).split(/\r?\n/)) {
      if (line !== '') pushLogLine(line);
    }
  };
  child.stdout.on('data', onData);
  child.stderr.on('data', onData);
  child.on('error', (err) => {
    const errText = err && err.message ? err.message : String(err);
    pushLogLine('[desktop] host process error: ' + errText);
    if (!quitting) {
      void showError('后台服务进程派生失败: ' + errText);
    }
  });
  return child;
}

function stopHost(child) {
  return new Promise((resolvePromise) => {
    if (child.exitCode !== null || child.signalCode !== null) {
      resolvePromise();
      return;
    }
    const force = setTimeout(() => {
      if (process.platform === 'win32') {
        execFile('taskkill', ['/pid', String(child.pid), '/T', '/F'], () => resolvePromise());
      } else {
        try {
          process.kill(-child.pid, 'SIGKILL');
        } catch {
          try { child.kill('SIGKILL'); } catch { /* already gone */ }
        }
        resolvePromise();
      }
    }, 5000);
    child.once('exit', () => {
      clearTimeout(force);
      resolvePromise();
    });
    if (process.platform === 'win32') {
      execFile('taskkill', ['/pid', String(child.pid), '/T'], () => { /* graceful attempt only */ });
    } else {
      try {
        process.kill(-child.pid, 'SIGTERM');
      } catch {
        child.kill('SIGTERM');
      }
    }
  });
}

function createWindow() {
  const window = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 960,
    minHeight: 600,
    title: 'DSH Trading',
    backgroundColor: '#0b1220',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });
  // The bundled web frontend keeps the host's own brand in document.title;
  // the shell window is branded DSH Trading and must not inherit it.
  window.on('page-title-updated', (event) => event.preventDefault());
  window.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url) && !/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//.test(url)) {
      void shell.openExternal(url);
    }
    return { action: 'deny' };
  });
  window.webContents.on('will-navigate', (event, url) => {
    if (!/^https?:\/\/(127\.0\.0\.1|localhost)(:\d+)?(\/|$)/.test(url) && !url.startsWith('file://')) {
      event.preventDefault();
      if (/^https?:\/\//.test(url)) void shell.openExternal(url);
    }
  });
  // 渲染进程的 warn/error 落盘：客户端插件失败（例如 trading 客户端取自定义指标
  // 失败）此前只在渲染进程 console 里说，宿主日志零痕迹，排障时无法指认触发点
  // （2026-10-14 KDAS 排查）。info/log/debug 丢弃——GUI 的 info 噪音大。
  window.webContents.on('console-message', (...args) => {
    const line = rendererLogLine(consoleMessageArgsToEntry(...args));
    if (line !== undefined) pushLogLine(line);
  });
  // 未捕获异常的另外两条主进程可见通道：preload 抛未处理异常、渲染进程消失。
  window.webContents.on('preload-error', (_event, preloadPath, error) => {
    pushLogLine('[renderer] preload error ' + preloadPath + ': ' + String(error && error.message ? error.message : error));
  });
  window.webContents.on('render-process-gone', (_event, details) => {
    // clean-exit 是正常退出（关窗/退出 app），只有异常消失才是证据。
    if (details.reason === 'clean-exit') return;
    pushLogLine('[renderer] render process gone: reason=' + details.reason + ' exitCode=' + String(details.exitCode));
  });
  return window;
}

async function showError(message, extra = {}) {
  if (mainWindow === null || mainWindow.isDestroyed()) return;
  await mainWindow.loadFile(path.join(__dirname, 'error.html'));
  mainWindow.webContents.send('desktop:error', {
    message,
    log: logTail.join('\n'),
    logFile: logFilePath(),
    isMissingVCRedist: extra.isMissingVCRedist ?? false,
  });
}

/**
 * Drop the browser-session cookies left by earlier launches before the new
 * host issues its own. The host derives the cookie name from the request
 * authority (`127.0.0.1:<port>`) and the shell takes a fresh random port on
 * every start, so each launch leaves one more `dsh-auth-*` cookie behind and
 * nothing ever retires it. Chromium replays the whole jar on every request;
 * once the accumulated cookie header plus the multi-kilobyte `/plugins/??…`
 * combo URL overruns the host's request-header budget, the host answers 431
 * for the client batch and the GUI reports "Failed to load plugins" (measured
 * 2026-09-11: 63 cookies = 14 KiB of cookies beside a 2.8 KiB URL, 431 on the
 * application batch only). The tokenized URL loaded right after this issues a
 * fresh cookie, so the jar stays at one entry per launch.
 */
async function pruneStaleAuthCookies(targetSession, origin) {
  try {
    const jar = await targetSession.cookies.get({ url: origin });
    const stale = jar.filter((cookie) => cookie.name.startsWith(AUTH_COOKIE_PREFIX));
    for (const cookie of stale) await targetSession.cookies.remove(origin, cookie.name);
    if (stale.length > 0) pushLogLine('[desktop] pruned ' + String(stale.length) + ' stale dsh auth cookie(s)');
  } catch (error) {
    // Best effort: a stale jar must not block a launch, and the header budget
    // above still covers a grown jar.
    pushLogLine('[desktop] auth cookie prune failed: ' + String(error && error.message ? error.message : error));
  }
}

/**
 * Boot once, ignoring a call that arrives while a boot is in flight: the retry
 * button and the automatic host recovery can both ask for a host, and two hosts
 * on one home is the one outcome the shell must never produce.
 */
async function boot() {
  if (booting) {
    pushLogLine('[desktop] a boot is already in progress; ignoring this request');
    return;
  }
  booting = true;
  try {
    await bootOnce();
  } finally {
    booting = false;
  }
}

/**
 * Restart the host after an exit the shell did not ask for and say so on the
 * page the user is looking at; a failed restart falls back to that page.
 * @param {{ attempt: number }} plan
 */
async function recoverHost(plan) {
  await showError('后台服务进程意外停止，正在自动重启（第 ' + String(plan.attempt) + ' 次，最多 ' + String(HOST_RECOVERY_MAX) + ' 次）…');
  try {
    await boot();
  } catch (error) {
    const message = String(error && error.message ? error.message : error);
    pushLogLine('[desktop] host restart failed: ' + message);
    await showError(message);
  }
}

async function bootOnce() {
  // A recovery or a Retry must not read the host that just died: clear the URL
  // this boot is about to wait for.
  bootUrls.reset();
  const runtime = resolveRuntimePaths(resourcesRoot(), process.platform, process.arch, app.isPackaged);
  const { home, ignored } = selectDshHome(process.env, os.homedir());
  // 继承来的显式 DSH_HOME 若是宿主 home，落回它就会把交易数据、自定义指标与
  // profile 写进宿主实例（2026-10-14 实证），所以忽略它并明说忽略了什么。
  if (ignored !== undefined) {
    pushLogLine('[desktop] ignored inherited DSH_HOME=' + ignored + ' (not a trading home); using ' + home);
  }
  pushLogLine('[desktop] dsh home: ' + home);

  if (!fs.existsSync(runtime.nodeBin)) throw new Error('bundled Node runtime is missing: ' + runtime.nodeBin);
  if (!fs.existsSync(runtime.hostBin)) throw new Error('bundled dsh host is missing: ' + runtime.hostBin);

  const stamp = readStampFile(runtime.stampFile);
  const stampText = runtimeSeedStamp(stamp);
  const profileDir = path.join(home, 'profiles', 'trading-web');
  const action = profileAction(profileDir, stampText);
  if (action !== 'leave') {
    setStatus(action === 'seed' ? 'Installing the bundled web profile…' : 'Updating the bundled web profile…');
    pushLogLine('[desktop] profile action: ' + action + ' (' + stampText + ')');
    applyProfileSeed(runtime.profileSeed, profileDir, action, stampText, { appVersion: app.getVersion() });
  }

  // The profile is also maintained by the dsh CLI, whose install links core
  // packages against the global npm tree while this app spawns its own bundled
  // runtime. Two copies of a core package split module-level state, and a preset
  // then keeps its tools but loses its persona, its AGENTS.md and its skill
  // catalog. Normalize before spawning; see normalizeProfileCohort.
  const cohort = normalizeProfileCohort(profileDir, runtime.hostModules, { log: pushLogLine });
  if (cohort.relinked.length > 0) {
    pushLogLine('[desktop] normalized ' + cohort.relinked.length + ' core package link(s) to the bundled runtime');
  }

  setStatus('Starting the dsh host…');
  const port = await findFreePort();
  pushLogLine('[desktop] spawning host on 127.0.0.1:' + port);
  hostChild = startHost(runtime, home, port);
  const child = hostChild;
  const spawnedAt = Date.now();
  let exited = false;
  child.once('exit', (code, signal) => {
    exited = true;
    const diag = formatHostExitDiagnostic(code, signal, process.platform);
    pushLogLine(formatHostExitLine({
      code,
      signal,
      quitInitiated: quitting,
      elapsedMs: Date.now() - spawnedAt,
      message: diag.message,
    }));
    if (quitting) return;
    const plan = planHostRecovery({ exitTimes: unexpectedExitTimes, now: Date.now() });
    unexpectedExitTimes = plan.exitTimes;
    if (plan.recover) {
      pushLogLine(
        '[desktop] the shell did not ask for this exit; restarting the host (attempt '
        + String(plan.attempt) + '/' + String(HOST_RECOVERY_MAX) + ' within '
        + String(Math.round(HOST_RECOVERY_WINDOW_MS / 60000)) + 'min)',
      );
      void recoverHost(plan);
      return;
    }
    pushLogLine('[desktop] host restart budget spent; leaving the startup-problem page up (Retry resets it)');
    void showError(diag.message, { isMissingVCRedist: diag.isMissingVCRedist });
  });
  await waitForGui(port, { deadlineMs: READY_TIMEOUT_MS, isAlive: () => !exited });
  // The port answering is not the handoff: the host binds its web server, then
  // loads the profile's plugins and audits the startup entries, and only then
  // prints the tokenized GUI URL. A fixed grace period here used to give up and
  // load the bare URL, which is always a 401 page (the token is per-process and
  // this launch's cookie does not exist yet) — measured on the trading profile
  // 2026-10-15, the line landed after the old 5s window. Wait for the line
  // itself, for as long as the whole boot is allowed to take, and never load a
  // URL that cannot authenticate. The window stays on the splash until then.
  const target = await waitForTokenUrl({
    readUrl: () => bootUrls.read(),
    isAlive: () => !exited,
    deadlineMs: READY_TIMEOUT_MS,
    pollMs: 100,
  });
  await pruneStaleAuthCookies(mainWindow.webContents.session, 'http://127.0.0.1:' + port + '/');
  pushLogLine('[desktop] GUI ready, loading the tokenized URL');
  try {
    await mainWindow.loadURL(target);
  } catch (error) {
    const message = String(error && error.message ? error.message : error);
    // A page from a previous host keeps retrying its dead port, and that failure
    // is reported against this webContents: only the target's own failure means
    // this boot is broken (see isNavigationFailureFor).
    if (isNavigationFailureFor(message, target)) throw error;
    pushLogLine('[desktop] ignored a navigation failure from a previous host: ' + message);
  }
}

async function run() {
  mainWindow = createWindow();
  await mainWindow.loadFile(path.join(__dirname, 'splash.html'));
  try {
    await boot();
  } catch (error) {
    pushLogLine('[desktop] boot failed: ' + String(error && error.message ? error.message : error));
    await showError(String(error && error.message ? error.message : error));
  }
}

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow !== null) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
  app.whenReady().then(run).catch((error) => {
    console.error(error);
    app.quit();
  });
}

app.on('window-all-closed', () => {
  app.quit();
});

app.on('before-quit', (event) => {
  if (quitting) return;
  quitting = true;
  if (hostChild !== null) {
    event.preventDefault();
    const child = hostChild;
    hostChild = null;
    void stopHost(child).then(() => app.quit());
  }
});

ipcMain.on('desktop:retry', () => {
  if (quitting) return;
  // An explicit retry is a human decision: it also hands back the automatic
  // restart budget the host burned.
  unexpectedExitTimes = [];
  void run();
});

ipcMain.on('desktop:reveal-log', () => {
  shell.showItemInFolder(logFilePath());
});

ipcMain.on('desktop:open-vcredist-download', () => {
  void shell.openExternal('https://aka.ms/vs/17/release/vc_redist.x64.exe');
});

ipcMain.on('desktop:quit', () => {
  app.quit();
});

// Updater flow: relaunch + quit in one step (app.relaunch registers the new
// launch; the quit then goes through the normal before-quit host teardown).
ipcMain.on('desktop:relaunch', () => {
  app.relaunch();
  app.quit();
});

app.whenReady().then(() => {
  try {
    fs.mkdirSync(path.dirname(logFilePath()), { recursive: true });
    logStream = fs.createWriteStream(logFilePath(), { flags: 'a' });
  } catch {
    logStream = null;
  }
});
