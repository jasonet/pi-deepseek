# 统一资产台账（Unified Holdings Ledger）设计契约

> Issue #65。本文是两个并行实施流（node 半 / client 半）的共同契约：任何字段、路由、
> 事件名的改动必须先改本文并同步双工。目标架构与取舍见 Issue 正文，本文只写定稿。

## 1. 词汇

- `origin`：持仓血缘，`'paper' | 'live' | 'imported'`，创建后不可变。
- `kind`：用户面向标签，`'real' | 'sim'`。paper 源恒 sim、live 源恒 real（运行时推导，
  不落库）；imported 源缺省 real、**可改标**（截图也可能来自模拟盘）。
- 「待确认区」（staged）：Agent 解析截图后的缓冲，用户在抽屉确认/编辑后才转正式。

## 2. Holding 存储模型（@dshtrading/holdings，宿主侧）

```ts
export type HoldingMarket = 'crypto' | 'us' | 'cn' | 'hk'
export type HoldingCurrency = 'USD' | 'CNY' | 'HKD' | 'USDT'
export type HoldingKind = 'real' | 'sim'

export interface Holding {
  id: string                    // `hd-<ts>-<rand>`
  market: HoldingMarket         // 行情路由依据，必填
  symbol: string                // 连接器词汇（与行情 API 对齐，如 AAPL / 002714.SZ / BTCUSDT）
  name?: string                 // 显示名（截图里的中文名等）
  side: 'long'                  // 一期仅 long（股票/现货截图场景）
  size: number                  // 持仓数量 > 0
  entryPrice?: number           // 成本价；截图没有则缺省（uPnL 不显示）
  currency?: HoldingCurrency    // 缺省按 market 推导：crypto→USDT, us→USD, cn→CNY, hk→HKD
  account: string               // 用户命名账户（'富途'/'IBKR'/'币安'），必填，缺省 '默认账户'
  kind: HoldingKind             // 缺省 real
  note?: string
  source: 'imported'            // store 只承载导入持仓；paper/live 是运行时源
  importedAt: number
  updatedAt: number
}

export type NewHolding = Omit<Holding, 'id' | 'source' | 'importedAt' | 'updatedAt'>
```

- 文件：`~/.dsh/holdings/book.json`，原子写（tmp+rename），形状
  `{ revision: number, staged: Holding[], holdings: Holding[] }`。
- Store 接口：`snapshot()`（返回 revision+两区）、`stage(items: NewHolding[])`、
  `confirm(ids, edits?)`、`discard(ids)`、`add(item)`、`update(id, patch)`、`remove(id)`；
  全部写操作自增 revision 并落盘。
- 默认值推导（currency/account/kind）在 store 写入侧完成，读侧不做猜测。
- **现金行约定（2026-09-15）**：现金余额按同一模型记入——`symbol` 用币种代码
  （`USD` / `CNY` / `HKD` / `USDT`）、`size` 为余额、不填 `entryPrice`
  （现金无成本价、无 uPnL），例：「现金(USD) 8,746.49」→
  `{ market:'us', symbol:'USD', size:8746.49, currency:'USD' }`。客户端聚合把
  「`symbol` === 行币种」的行识别为现金（client 半 `isCashPosition`）并**按面值估值**
  （1 单位现金 = 1 单位该币种，再按 FX 折算），**不参与行情盯市**——`USD` / `HKD` /
  `CNY` 在行情 API 里都是真实标的（`us:USD` = ProShares Ultra Semiconductors），
  套用其报价会把现金余额乘成几十倍的伪总资产。

## 3. REST 契约（/dshtrading/api 桥，认证栅栏后）

| 方法 | 子路径 | body | 返回 |
|---|---|---|---|
| GET | `/holdings` | — | `{ ok:true, revision, staged: Holding[], holdings: Holding[] }` |
| POST | `/holdings/stage` | `{ items: NewHolding[] }` | `{ ok:true, revision }` |
| POST | `/holdings/confirm` | `{ ids: string[], edits?: Record<string, Partial<NewHolding>> }` | `{ ok:true, revision }` |
| POST | `/holdings/discard` | `{ ids: string[] }` | `{ ok:true, revision }` |
| POST | `/holdings` | `NewHolding` | `{ ok:true, revision, id }` |
| PUT | `/holdings` | `{ id: string, patch: Partial<NewHolding> }` | `{ ok:true, revision }` |
| DELETE | `/holdings` | `?id=` | `{ ok:true, revision }` |
| GET | `/fx?base=USD` | — | `{ ok:true, base, rates: Record<string,number>, asOf: number, stale: boolean }` |

- 全部写成功 → `tradingEvents.emit('holdings')`（SSE store 名 `'holdings'`）。
- 桥侧 envelope 惯例不变：业务错误 HTTP 200 + `{ ok:false, code, message }`；
  校验失败 code `TRADING_HOLDINGS_INVALID`。
- FX：`rates` 语义「1 单位基准币 = rates[c] 单位 c」……**改为更直观的
  `rates[c] = 1 单位 c 折合多少 base`**（USD 基准时 `{USD:1, USDT:1, CNY:0.14, HKD:0.128}`）。
  `stale:true` 表示用了过期缓存（首次拉取失败且无缓存时 `stale:true` + rates 只含
  `{base:1, USDT≈USD}` 兜底恒等项）。

## 4. FX 服务（@dshtrading/holdings/fx）

- 源：`https://api.frankfurter.dev/v1/latest?base=<base>&symbols=USD,CNY,HKD`
  （ECB 汇率，免费无 key，个人用途；USDT 不入请求，恒定锚定 USD：`rates.USDT = rates.USD`）。
- 宿主内存缓存 1h + 文件缓存 `~/.dsh/holdings/fx-cache.json` 兜底（重启可用）。
- 失败链：内存 → 文件 → 恒等兜底；后两者 `stale:true`。fetch 超时 5s。
- base 支持 USD/CNY/HKD；非法 base → 400。

## 5. Agent 工具（holdings plugin，host 平面注册）

> 2026-09-08 修订：台账是**导入型记录**，agent 对记账面拥有完整控制权（用户定案：
> 「理论上 agent 应该能完全操控这些资产，除了不能直接买入和卖出标的」）。原「唯一写
> 入口 = stage」收敛为**截图导入的默认路径**，不再是权限边界；确认/修订/删除全部开放
> 给 agent，纪律由 description 承载（回显、核对、提醒用户复核）。

| 工具 | 作用 | 关键纪律 |
|---|---|---|
| `holdings_stage(items)` | 截图解析 → 待确认区 | 数字原样取自截图、缺省不编造；回显后提醒用户到面板确认 |
| `holdings_confirm(ids, edits?)` | 待确认区 → 正式持仓 | 确认后必须列出确认了哪几条（id + 关键字段） |
| `holdings_discard(ids)` | 丢弃待确认区条目 | 先说明丢的是哪几条，再回显剩余条数 |
| `holdings_add(items)` | 口述/手动录入直接进正式区 | 数字原样取自用户口述，不编造；截图导入仍优先走 stage |
| `holdings_update(id, patch)` | 修订正式持仓字段 | 回显「旧 → 新」；改 market 未给 currency 时按新市场重推导 |
| `holdings_remove(ids)` | 删除正式持仓（平仓/清重） | 明确「这是记账不是下单」，删后提醒用户自行核对账户真实状态 |
| `holdings_list()` | 只读概要（含 id） | 两区 id 来源；不得凭记忆复述 |

- 工具**不经过审批闸门**（ORDER_GATE_PATTERN 不匹配，天然放行）：纯本地数据，无交易语义。
  记账与下单严格分离——任何台账工具都不会触发买卖，也不改变券商/交易所账户里的真实持仓。
- 区隔提示：`update/remove` 只作用于正式持仓区；待确认区条目的修订走 `confirm` 的
  `edits`、移除走 `discard`，工具对跨区 id 返回指向正确工具的提示。
- 全部写成功 → `tradingEvents.emit('holdings')`（与 REST 写路径同一失效信号）。

## 6. Client 半（client-ui-trading）

### 6.1 类型（client/holdings-types.ts，不动 @dshtrading/api）

```ts
export type PositionOrigin = 'paper' | 'live' | 'imported'
export interface TaggedPosition extends Position {   // 结构扩展，契约不改
  origin: PositionOrigin
  kind: 'real' | 'sim'
  market: MarketId | undefined  // paper 旧数据可能未知 → undefined
  account: string               // paper→'模拟账户' live→provider 名 imported→用户命名
  holdingId?: string            // origin==='imported' 时回指 store 记录
  currency?: HoldingCurrency
}
```

### 6.2 聚合引擎（client/holdings-aggregate.ts，纯函数，vitest 重点）

输入 `TaggedPosition[]` + `prices: Record<`${market}:${symbol}`, number>` + fx → 输出：
- 明细行：markPrice、marketValue（原币 + 折算）、uPnL（原币 + 折算，无成本价则 undefined）；
- 汇总行：按 `market:symbol` 聚合（总 size、加权成本、总市值、总 uPnL、来源/账户分布）；
- 顶部小计：按 origin 分（真实/模拟/实盘）、按币种分；总资产 = Σ折算市值。
- FX stale 或缺汇率 → 该币种进「未折算小计」分区，总资产仍给出但标注近似。
- 现金行（`symbol` === 行币种，见 §2）：markPrice 恒 1、市值 = `size` 原币（再折算），
  无成本价、无 uPnL，也不进成本合计（否则浮动盈亏比例的分母被现金稀释）；同市场同币种的
  多账户现金合并成一条汇总行（可展开分账户明细）。

### 6.3 UI（TradeDrawer 重构 → 2026-09-05 侧栏化为 HoldingsPanel）

> 2026-09-05 修订：底部全宽资产抽屉（TradeDrawer）移除，改挂 QuoteStage
> chartRow 右缘 300px 竖栏资产面板（HoldingsPanel，工具栏「资产」按钮开关，
> `dshtrading.holdingsPanel.open` 持久化，默认开）。本节交互语义不变，
> 展示形态由宽表格改为紧凑卡片/行列表；「手动新增」升级为面板头部常驻
> 「+ 添加资产」主按钮。仅图表页签展示（与原抽屉一致）。

- 持仓 tab：统一表，新增列「来源」（徽章：模拟/实盘/真实导入）、「账户」、「市值」；
  过滤 chips：全部/真实/模拟/实盘。imported 行支持编辑/删除（对话框）。
- 新增「汇总」tab：聚合行可展开分账户明细；顶部基准币选择（USD/CNY/HKD，
  localStorage `dshtrading:holdings:baseCurrency`，缺省 USD）+ 总资产 + 分来源小计。
- 待确认横幅：staged 非空时面板置顶条「N 条待确认持仓」→ 确认对话框
  （可编辑表格：market/symbol/size/entryPrice/account/kind）→ 确认/丢弃。
- 持仓录入走「手动新增」对话框（同字段表单）；截图解析入库由 Agent 的
  `holdings_stage` 工具完成（客户端不再提供「导入持仓」会话填入入口）。
- 价格供给：面板展开时对全部持仓按 market 分组 fetchTickers 批量盯市，
  30s 轮询；折叠时暂停（现金行不是报价标的，不进盯市目标）。paper 持仓维持现有
  updatePrices 链路不变。
- 委托/成交/资金 tab 语义不变（仍随 live/paper 模式）。

### 6.4 其他

- 缺省 tradeMode 翻转：localStorage 无记录时 paper（已有显式记录不动）。
- paper store：placeOrder 记录 market（PaperPosition = Position & { market?: MarketId }），
  旧数据无 market → TaggedPosition.market = undefined（汇总显示「未知市场」，不参与批量盯市，
  维持原 activeMarket 盯市行为）。
- live 源：对四个市场逐个 GET /trade/positions?market=（失败静默跳过），
  origin='live'、kind='real'、account=该市场 provider 名。
- locales：新增 key 走 contract.ts MarketLocaleKey 联合类型 + zh/en 双语（i18n 包构建期自动拾取）。

## 7. 测试基线

- holdings 包：store 全操作 + 默认值推导 + revision 自增 + 原子写；fx 缓存/降级链；
  工具 stage/list/confirm/discard/add/update/remove 行为（含校验整体拒绝、跨区 id 提示、
  回显文案与 onWritten 回调）。vitest。
- client：聚合引擎（多来源/多币种/加权成本/缺成本价/FX stale 降级）；
  api 封装 envelope 解析。vitest。
- 全仓 `pnpm build` `pnpm test` 绿。
