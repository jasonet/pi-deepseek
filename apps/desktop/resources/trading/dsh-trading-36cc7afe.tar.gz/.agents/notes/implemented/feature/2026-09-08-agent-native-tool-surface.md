# Agent Note: agent-native 工具面增强落地（审计缺口卡 G1-G5/G7/G8）

Status: implemented

## Problem

`../architecture/2026-09-08-agent-native-plugin-interface-audit.md` 的逐包三面审计结论：多处能力的 Registry/Store 与 View 都在，唯独 Tool 边缺席——用户说「把美股行情源换成 Alpaca」「用选股器扫一遍 A 股」「我美股账户有哪些挂单」「看一下 BTC 盘口和最近逐笔」「把我上次调过参数的那个策略再回测一次」，agent 要么只能回「请到设置面板点」，要么只能让用户报 id。本记录落地审计 §4 实施顺序中的 A 类缺口（G1-G5、G7、G8），并记录与审计建议的偏差、待裁决项与实证结论。

## Decision

### 落地形态（逐缺口）

| 缺口卡 | 落地工具 | 所在平面 | 数据源 | 风险级 |
|---|---|---|---|---|
| G1 账户读面 | `<market>_get_positions` / `_get_orders` / `_get_fills` / `_get_balance` / `_get_order`（4 市场 × 5） | host（新行 `@dshtrading/base/market-tools`） | `tradingTradeRegistry` 路由选中的 TradeService | A |
| G2 盘口/逐笔 | `<market>_get_orderbook` / `<market>_get_trades`（4 市场 × 2） | host（同上） | `tradingMarketDataRegistry` 路由选中的 MarketDataService | A |
| G3 名册读取 | `strategy_list` / `screener_list`；`strategy_backtest` 增 `paramsJson` | host（strategies/plugin） | 自定义 store + 内置范式 + 墓碑表 | A |
| G4 选股器执行 | `screener_run` | host（strategies/plugin） | registry 名册 + 500 根日 K + 纯函数 evaluate（vm 熔断） | A |
| G5 自选分组 | `watchlist_group_create` / `_rename` / `_delete` / `_assign`；`watchlist_list` 回显 groups/selection | host（watchlist/plugin） | 分组注册表 + 行 groups 字段（与桥同一 file store 实例） | A |
| G7 FX 汇率 | `fx_get` | host（holdings/plugin） | FxService（与桥 GET /fx 同一实例与缓存） | A |
| G8 衍生品历史 | `crypto_get_derivatives_history` | preset（kit-crypto） | 路由选中的 crypto 行情服务 | A |

### 与审计建议的两处偏差（都是刻意收敛，不是遗漏）

1. **市场/账户工具改为 registry 驱动，不逐连接器接线**。审计原文建议「工具工厂 + 各连接器接线（按市场分别提测）」；照做的代价是同一能力在 30 个连接器里各写一遍，必然漂移（审计自己就记录了 `get_indicators` 只在 binance/okx 注册、provider=bybit/ccxt 时缺失的先例），且第三方连接器永远补不齐。改为：两个工具族由 `tradingMarketDataRegistry` / `tradingTradeRegistry` 在**调用期**解析路由选中的服务，工具名固定、实现随 provider 走——零连接器改动即覆盖全部 provider（含第三方），且与既有 `base/research-tools` 的 registry 语义一致。
2. **未实现语义显式化**。可选方法缺席时抛 `TRADING_NOT_IMPLEMENTED`（`packages/api` 既有错误码），绝不返回空数组冒充「无持仓/无挂单/空盘口」；「市场无激活 provider」「该市场没有交易连接器」「注册了但当前路由指不到」三种情形分别用 `TRADING_NO_PROVIDER` / `TRADING_NO_TRADE_SERVICE` / `TRADING_TRADE_PROVIDER_NOT_ROUTED`（`packages/api` 的 `TradingErrorCode` 联合扩展，向后兼容）。

### 关键接线与安全边界

- `@dshtrading/base/market-tools` 是新的 host 平面共享行（base 拥有全部市场无关行，铁律 #1），行 id `dsh-trading-market-tools`，insert-only 追加在 base 的 `cordis.patch.yml`。同名工具先到先得，**host 平面先注册因此胜出**（真实会话实证，见下）：连接器（如 okx 的 `crypto_get_positions`）与工厂都带 `tools.get(name) === undefined` 守卫，两侧都不会抛重名错；okx 侧三个同名只读工具保留为守卫兜底。
- 全部新工具**零交易语义**：不命中 `ORDER_GATE_PATTERN`，不进审批闸门；`screener_run` 只读行情 + 本地纯函数计算，`fx_get` 只读汇率，分组工具只写自选注册表。
- 写后 emit：分组工具复用 `tradingEvents.emit('watchlists')`（GUI 左栏实时刷新）；只读工具不 emit。
- 分组注册表单实例：`WatchlistStoreService` 增加 `groups` 字段，桥（client-ui-trading）优先解包服务实例、缺席才回退自建——避免审计点名的「双 store 整表回写互相覆盖」前科。
- `screener_run` 护栏显式回显（并写进 `docs/design/strategy-tab.md` §3.4b）：扫描池上限（默认 100 / 上限 500）、并发 5、单标的取数超时 8s、求值超时 1s（自定义源码走 Node vm 熔断）、单次总预算 90s（耗尽后 `deadlineExceeded:true`，替代 agent 面缺失的取消通道）、结果上限 50（`truncated` 标记）、`failed` / `insufficient` 分开计数（数据不足按契约静默跳过，不混入失败）。
- okx 的 `OkxTradeService` 增可选 `environment()` 自述方法（demo/live 安全信号），由账户工具鸭式读取并写入输出 `environment` 字段——api 契约不声明该可选方法。

## Alternatives considered

- **逐连接器接线（审计原文建议）**：30 个连接器 × 7 工具的实现与测试面，provider 之间必然漂移，第三方无法补齐；registry 驱动一次覆盖，代价是工具输出形状必须收敛为 provider 无关的统一信封（已如此）。
- **给每个市场单开一个插件/服务**：与 `base/research-tools` 的既有 registry 语义重复，且 host 平面行数无谓膨胀；一个 `market-tools` 行 + markets 配置足够。
- **把账户只读工具放进 preset 平面（research-tools 同层）**：trader/master 预设挂的是连接器而非 research-tools，专家角色反过来不挂连接器——只有 host 平面能同时覆盖两类会话。
- **`screener_run` 复用客户端扫描调度**：调度只在 `ScreenerPane`（浏览器半），host 无法复用；改为在 strategies 插件内复刻同口径调度并显式回显护栏，自定义源码统一走 vm 熔断。
- **账户读面纳入审批闸门**：闸门语义是「真实交易前置确认」（铁律 #3），只读查询纳入会让日常核对也要审批；按审计裁决走 A 类。
- **`fx_get` 让 agent 自取公开汇率**：口径与台账不一致且丢失 stale 语义，等于给模型一个更差的第二数据源。
- **本轮顺手做 G6 `routing_set`**：B 类（影响分析结果），审计要求先定 settings 写契约 + `'routing'` 事件语义 + 审计留痕格式；settings 服务确实暴露 `update(ns, patch)`，但深层合并语义与留痕格式需要 owner 裁决，本轮不动（见 Consequences）。
- **本轮顺手补 C 类撤单工具**：直接违反铁律 #3 与审计 §5，不做。

## Consequences

- **工具面增量**：host 平面 +36（28 市场/账户 + `strategy_list`/`screener_list`/`screener_run` 3 + `watchlist_group_create/_rename/_delete/_assign` 4 + `fx_get` 1），preset 平面 +1（`crypto_get_derivatives_history`）。审计 §5.6 的「一次成型后冻结」窗口按记录重开一次并再次冻结（见 `docs/design/agentic-native-architecture.md` §5.6）。
- **测试**：`packages/base/test/market-tools.test.ts`（工具级：成功/NOT_IMPLEMENTED/无 provider/无交易连接器/注册面幂等/闸门命名族零命中）、`packages/base/test/market-tools-wiring.test.ts`（真实 cordis Context 上 router + market-tools + watchlist + strategies + holdings 同表接线，含 screener_run 端到端与分组写读闭环）、`packages/strategies/test/{plugin-list,backtest-params,screener-run}.test.ts`、`packages/watchlist/test/groups-tools.test.ts`、`packages/holdings/test/tool-fx.test.ts`、`packages/kit-crypto/test/derivatives-history.test.ts`。
- **2026-09-08 历史门禁**：165 文件 / 1370 用例、typecheck 481 是当时证据，不是当前基线；当前收口证据见下节。
- **运行时实证（真实宿主，2026-09-08）**：
  - `trading-dev` profile 刷新包副本后 `--dump-config` 确认新 host 行 `dsh-trading-market-tools` 进组合树；一次真实 headless 会话（`dsh-trading --profile trading-dev --patch <禁用 web 专属社区行> "Reply with exactly: ok"`）的 session transcript 里 93 个工具，含四市场 `_get_orderbook/_get_trades/_get_positions/_get_orders/_get_fills/_get_balance/_get_order`、`fx_get`、`strategy_list`、`screener_list`、`screener_run`、`watchlist_group_create/_rename/_delete/_assign`。
  - **真实调用实证**（同 profile，master 预设，只读提示词）：`routing_get`、`strategy_list`（6 范式）、`screener_list`（5 内置）、`watchlist_list`（含 groups/selection 回显）、`crypto_get_orderbook(BTCUSDT)`（provider=okx，真实盘口 20 档）、`fx_get(USD)`（ECB 汇率，stale=false）全部 `ok:true`；preset 平面的 `crypto_get_derivatives_history` 在该 headless 一次性会话里未进入工具面（preset scope 工具与 headless 一次性会话的已知行为），其行为由 `packages/kit-crypto/test/derivatives-history.test.ts` 与 `pnpm --filter @dshtrading/kit-crypto test` 覆盖。
  - **同名工具归属实证**：改用 `default: master` 预设（真实挂载 okx 连接器）再跑一次会话，transcript 里 `crypto_get_positions` 的 description 是**工厂文案**（"Read-only crypto account positions from the currently routed trade connector…"）——即 host 平面先注册、okx 的 `registerTool` 守卫跳过其同名工具。okx 的 demo/live 安全信号因此经 `OkxTradeService.environment()` 由工厂读出，未丢字段；okx 侧三个同名只读工具成为守卫兜底（未删除，保留非标准组合下的可用性）。
  - 桌面壳（trading-web）实例当时正在运行，未执行 `dsh plugin install`（铁律：实例运行中禁止），故 App 内对话验收待刷新 profile + 重启后进行。
- **独立审查轮（2026-09-08，findings-first）修复项**：P1（us/cn 账户读面错误码误报「没装交易连接器」）→ 新增 `TRADING_TRADE_PROVIDER_NOT_ROUTED` 并列出已注册 provider 与 `dshtrading.markets.<m>.tradeProvider` 设置键；P2 全清：`getPositions`/`getOrder` 补可选方法探测（第三方 provider 不再抛裸 TypeError）、okx 守卫 warn 文案改为「host 平面已拥有该名 / 另一 provider 互斥」二义澄清、`crypto_get_order` 入参由 okx 原生 `(instId, ordId)` 变为统一 `(symbol, orderId)`（已在工具 description 写明）、`truncatedTo` 仅真截断时回显并补 `truncated`、`strategy_list`/`screener_list` 的 `deleted` 按族过滤、桥分组端点补注入实例断言（`service-wiring` GET+POST）、`screener_run` 市场键文案区分「键写错」与「没装连接器」、`fx_get` 非字符串 base 拒绝（schema 层已先拒）。
- **已知语义边界（如实记录，非缺陷）**：账户读面读的是 **host 数据面行的交易实例**（`tradingTradeRegistry`），与 preset 行里 `place/cancel` 用的实例相互独立——okx 的 `env`（demo/live）若只改 preset 行而不同步改 host 行（`packages/crypto/cordis.patch.yml`），下单走实盘而账户读面仍读 demo。GUI 交易台此前就是同一分裂；工具输出已带 `environment` 自述（来源即该 host 实例），可据此判断。
- **待裁决（本轮不做）**：
  - G6 `routing_set`（B 类）：需先定 settings 写契约（深层合并语义）、`'routing'` 事件语义与审计留痕格式；agent 侧目前仍只能读 `routing_get` 并引导用户到设置面板。
  - G9 图表指标名册迁移导入、G10 更新器：维持审计 §5 的「不做」判定。
  - **审计 Wave 3 的文案项已部分落地**（2026-10-03，见下「工具描述体例」）：`Read-only` / `No credentials required` / `dryRun` 三类跨工具重复纪律**尚未**上移 persona（R3-A4，会同时改 4 个角色前缀，需先加后删两步），同名双源（`crypto_funding_rate` kit-crypto vs okx、`us_get_news` kit-us vs finnhub）**不做合并**——两处语义不同（当前+下期 vs 历史序列）或供应商不同，跨文件同名统计是静态候选，不是运行时碰撞；固定 MARKET 修正与 scope 决策归 [作用域 Note](../architecture/2026-08-31-agentic-native-plugin-decomposition.md#L32-L55)。
  - C/D 类（下单/撤单/paper/liveTrading 开关/凭据）：按铁律 #3 与 §5 一律不开放。
  - **默认路由下 us/cn 账户读面不可用（需 owner 裁决）**：`TradeRegistryService` 按 `tradeProvider ?? provider` 严格解析且不静默降级，而默认配置 us=yahoo（数据）/ alpaca（交易）、cn=tencent / qmt 数据面与交易面不同名，因此账户工具在默认配置下只能返回 `TRADING_TRADE_PROVIDER_NOT_ROUTED`。三条可选路径：(a) 用户在 settings.yaml 显式设 `markets.us.tradeProvider: alpaca`（当前唯一可行，已写进 `docs/guides/exchange-routing.md` §2.4）；(b) 设置面板补 tradeProvider 行；(c) 改注册表语义（数据 provider 无交易面时回落该市场唯一注册的交易服务——会推翻 `router/test` 里「选中了但未注册 → undefined，不静默降级」的既有裁决）。本轮选 (a)+精确报错，未擅自改语义。
- **实证发现（与本变更无关，已登记 [issue #88](https://github.com/zhu1090093659/dsh-trading/issues/88)）**：
  - Windows CI flake：`packages/indicators` 试算 100ms 超时（`validate.ts:26`），docs-only 提交同样复现，重跑即绿。
  - `trading-dev`（headless）profile 在 `dsh --profile trading-dev "..."` 下启动失败——`@linxin666/dsh-session-archive`、`@xmanrui/dsh-im`、`@linxin666/dsh-usage`、`@linxin666/dsh-client-ui-plugin-manager` 四行等待 `webServer`/`connection` 服务而 headless 宿主没有，`assertEntriesActivated` 直接抛错。来自 2026-09-08 的 `466cbe1`（另一会话的三插件内置），修法可参照同文件 `dsh-trading-dynamic-capabilities` 行的条件禁用范式；本变更未改。
- **时效**：`trading-web` profile 的包副本是 `file:` 拷贝而非 symlink，运行时生效需 `scripts/refresh-trading-web-profile.sh` 刷新副本 + 重启宿主（桌面壳需重启 App）。本变更只跑通包级与真实 cordis 接线验证，未动用户正在运行的桌面实例。

## 工具描述体例（2026-10-03，S1 与 Lead 收尾）

工具面冻结期（`docs/design/agentic-native-architecture.md` §5.6）内**不新增工具**，只统一既有工具的模型可见文本。当前静态扫描含独立 bot-api 回迁的 6 个定义，共 155 个 defineTool 定义；这不是会话实际可见工具数。体例与事实：

- **体例**：工具级 `description` = [做什么 一句] + [本工具特有约束] + [失败语义]，**<=480 字符且 <=90 词**、英文、无 Markdown/emoji/换行/URL；参数级 `description` 单句 3-16 词。官方参照 `@deepseek-ai/dsh-experimental-tool-agent-team@0.2.0-rc.2` 九工具（实测 62-259 字符 / 11-39 词，参数 26 个全部有说明）。参数级超长时，字段词汇表与默认值约定下沉到该工具自己的参数 description——模型在同一次工具调用里仍看得到，请求前缀不额外膨胀。
- **边界**：只改 `description` 与参数 `description` 文本。工具名、patch 行 id、`parameters` 结构与必填性、`output.schema` 类型、执行逻辑与运行时返回文本（holdings 的 `[tool]` 前缀、renderFundingRates 输出等随用户语言）**一律不动**。
- **语言口径**：描述统一英文，依据 [预设注入文本统一英文](2026-09-06-english-persona-unification.md)。中文只保留在**值示例**里（`贵州茅台`、`600519.SH` 这类标的/标签字面量），说明文字本身不得是中文。
- **失败语义三态**保持可区分：`TRADING_NOT_IMPLEMENTED`（provider 未实现该能力 ≠ 无数据）、`TRADING_NO_PROVIDER`（市场无激活 provider）、`TRADING_NO_TRADE_SERVICE` / `TRADING_TRADE_PROVIDER_NOT_ROUTED`（未注册 vs 注册了但路由指不到）。基准文本仍是 `packages/base/src/market-tools.ts` 的 `notImplementedError`。
- **落地结果**：S1 压缩长描述后，Lead 的 `ff5f454d` 补齐三条新闻工具的遗漏；该 SHA 的 R3 口径（>480 字符或 >90 词）超限为 0。inventory 的 >400 字符观察阈值仍有 29 条，阈值不同，不表示 R3 体例未完成；22 条中文工具/参数描述英文化（holdings 8、knowledge 4、xysz 4、kit-cn 2、jin10 2、watchlist 2）；base 的必填 `symbol` 参数补齐说明。对照表与逐条保留约束见 gitignored 的 `.local/tool-surface/S1-changes.md`；量化脚本 `scripts/tool-surface-inventory.mjs`（R2 产物）可复跑数字。
- **未做的部分（明确记录，避免下次从零讨论）**：跨工具重复的通用纪律（`Read-only` / `No credentials required` / `dryRun` 提示）**未上移** `composePresets()` persona——那会同时改变 4 个角色的系统提示词前缀，按「先加 persona、验证一轮真实会话、再删工具层重复句」两步执行，属独立窗口；同名来源的 provider 可辨识度只补了 xysz/stooq/ibkr/longbridge 四处，统一的 "which provider serves this call is decided by routing_get" 句需与 persona 上移同批做（否则会把 7 条已接近上限的描述推过 480 字符）。

## 2026-10-03 工具面收口（S4）

- **决策归属**：本记录拥有描述体例与总收口；S2 的 watchlist_add/remove 对象 canonical 输出与外部直接 execute API 变化归 [自选 SSOT Note](2026-09-01-watchlist-host-ssot.md)，S3 维持 preset/host 现状与 fork 继承边界归 [作用域 Note](../architecture/2026-08-31-agentic-native-plugin-decomposition.md#L32-L55)。不扩大 schema 试点、不复制逐 Agent 安装器，避免把共享工具重装误作权限收窄。
- **绑定证据**：受测 HEAD `ff5f454d367e277340498f2761945c17d9af39a5`，工作区在完整门禁前后均干净。`pnpm gates:all` 默认 14/14 通过，build 59 项完成；递归测试 52 包报告、1717 passed、2 skipped（OKX demo 无凭证）；scripts 11 文件/94 例、desktop 29/29；独立 `pnpm test:scripts` 同为 94/94。逐项完整输出保存在本机 gitignored `.local/tool-surface/S4-logs/`，定稿 `.local/tool-surface/S4-final.md`。没有使用 --update。
- **棘轮事实**：test:audit 1777 用例，mock/sleep/bdd-title/bdd-gwt/weak-assert 为 199/0/1527/1526/0，相对 199/0/1528/1528/0 无逐文件新增债；覆盖率 branches/lines/functions/statements 为 74.31/62.63/71.99/62.63%，高于 74.25/60.89/70.22/60.89%，52 包无缺报告。typecheck 75 tsconfig、429 存量错误等于基线；patch-id 54 行/1 覆盖等于冻结表；repo-boundary 零违规；i18n 5 namespace/992 zh keys、29 豁免/163 host warning；docs-link 无新增断链（18 存量）。
- **安全回归**：相对 `03296370`，base 审批代码/测试、authority 整目录、presets 与既存交易镜像配置无改动。S1 与 Lead 仅改描述（附带尾逗号格式），S2 仅改自选输出契约及消费测试。ORDER_GATE_PATTERN 仍收口六市场下单/撤单；schema dryRun 默认 true，审批层仅显式 true 继续 next，缺省/false/异常仍 ask。live-trading 门禁实测 7 镜像全部 false、281 源文件无裸判定/签署引用、自铸授权平面被拒。独立 bot-api 回迁不归 S1/S2，不把全树 diff 冒称纯文本。
- **残留边界**：本轮没有 live trading、profile 刷新或重启，没有当前 trading-web 工具可见集、live cohort、preset 卸载/切换与 fork 硬隔离验收。静态定义数/同名候选不证明运行时注册顺序；通用纪律 persona 上移、开放字典输出与其他工具 string schema 保留。不用门禁绿替代这些实证。进程检查仅见既存 Typeless/Chrome crashpad，无本轮 node/vitest 孤儿。

## 2026-10-03 残留缺口处置（收口后补做）

上一节列出的残留缺口在本日继续关闭，逐项状态如下。

- **运行时工具可见集（已实证，headless）**：`DSH_HOME=~/.dsh-trading dsh-trading --profile trading-dev 'Reply with exactly: ok'` 真实跑通（session `session-dc88f92e-b61a-49bd-b2e7-396197cc69d2`，退出 0）；会话记录里一次出现 127 个工具名，含六市场 `<market>_get_orderbook/_get_trades/_get_positions/_get_orders/_get_fills/_get_balance/_get_order`（crypto/us/cn/hk/futures/global）。这回答的是"这棵组合树下工具确实被装配并可见"，不是"同名工具谁赢了路由"——后者仍无运行时证据。trading-web 实例的工具可见集仍未验（无运行实例）。
- **输出契约声明化 Batch 1（已落地）**：`packages/base/src/market-tools.ts` 七个工具与 `research-tools.ts` 两个工具改为官方 `jsonOutput(valueSchema)` 形态，共享 helper `packages/base/src/tool-output.ts`（闭合对象、`additionalProperties: false`、`required` 齐备、render 紧凑 JSON）。canonical 值与旧 `JSON.stringify` **逐字段同形**，模型可见文本不变；变更点是 execute 返回值受 `InferValue` 编译期检查、非法形状在 `ToolRuntime` 被 `ToolOutputError` 拒收。验证：`pnpm --filter @dshtrading/base test` 44/44、包 `tsc --noEmit` 干净、`pnpm test:audit` 与 `pnpm test:scripts` 无新增债、`pnpm coverage:check` 通过（base 单项 97.97/92.15/84.29，高于基线）。`scripts/tool-surface-inventory.mjs` 复跑：`jsonOutput` 3→15、`outputSchemaValueForm` 2→11。Batch 2/3/4 仍按 R3 分批策略待排期。
- **schema 形状的兼容承诺（已定）**：工具**名**与 patch 行 id 是跨版本冻结契约（`patch-id-freeze.json` + 门禁）；`output.schema` 与 execute canonical 值是**包内契约**——同一 Delivery 内注册面与消费面一起改，不做 N-2 双形状。因此 Batch 2/3 的 connector 行情族不需要"先定 N-2 策略"这一前置，直接按包分批即可；跨版本破坏性变更仍受 changeset/版本协商约束（见 [契约包版本策略](../architecture/2026-10-01-contract-package-ids-and-versioning.md) 的 N-2 窗口，那条管的是客户端 wire，不是工具输出形状）。
- **profile 副本刷新（已修并跑通）**：`DSH_HOME=~/.dsh-trading bash scripts/refresh-trading-web-profile.sh` 首跑被 preflight 挡住——`pnpm-workspace.yaml` 里 `@dshtrading/bot` 指向随 2026-10-03 自动交易平面切走的 `packages/bot`，属死路径。根因是 `scripts/sync-profile-overrides.mjs` 对"本仓域名但仓库已无此包"的行只告警不删。已修为删除该类行（同时保留 @deepseek-ai/* 未知行并告警），并补 `scripts/sync-profile-overrides.test.mjs`（2 例，夹具驱动）。修后刷新成功：`OK（78 条 file:/link: 行）`、58 包重装、宿主核心包 symlink 重挂；副本 `base/lib/market-tools.js` 与仓库构建产物 md5 一致（`1be4a276…`），即 Batch 1 已进入 trading-web 副本。当时无运行中的 trading-web 实例，刷新未中断任何会话。
- **description >400 观察阈值存量（明确为口径差异，不处理）**：体例硬上限是 >480 字符或 >90 词，该口径已为 0；>400 是 inventory 的观察阈值（当前 29 条），低于硬上限即合规，不设整改目标。
- **尚存限制**：同名工具运行时胜者、live cohort、trading-web 实例的工具可见集与 profile 副本刷新、preset 卸载/切换与 fork 硬隔离仍未验证；开放字典输出（`fx_get.rates`、`watchlist_list.sources/watchlists`）与其他 144 处 `type: 'string'` 输出按 R3 分批策略保留。
