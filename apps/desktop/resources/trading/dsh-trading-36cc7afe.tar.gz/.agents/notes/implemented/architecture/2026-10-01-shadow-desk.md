# shadow 装置：零 venue 写、决策卡片、provenance 可重建

日期：2026-10-01 · 阶段：P3 步骤 5 · 卡片：317a623f · 包：`@dshtrading/tradectl/shadow`

## 事实

- **零 venue 写是结构保证，不是约定**：`createShadowDesk` 的参数里**没有**下单端口——没有可调的东西。测试里那个会计数的假 venue 存在的唯一目的，就是证明它一次都没被碰过（`calls === 0`）。
- **决策卡片五要素**：触发源 / 论点 / 动作 / 结果 / **命中哪条限额**。风控闸门挡住时命中记为 `riskGate`（原因不是额度而是档位），额度挡住时点名具体限额。
- **限额判定顺序固定**（先到先挡）⇒ 同一输入永远同一结论 ⇒ 这是"可重建"的前提。
- **provenance 足以重建判定**：卡片带判定价格与年龄、持仓快照版本、mandate 版本指针与散列、行情世代与对齐状态、desk 档位；`rebuildDecision` 用这些输入重跑，结论一致才算可重建。
- **不可重建就明说**：价格超过年龄预算的卡片标为不可重建（状态叙述里单独计数），重建时拒绝假装；重建输入与当时不一致会以 `limit mismatch` 暴露出来。
- 卡片落 append-only journal（`shadow.decision`）；`narrative()` 给出决策数 / 被挡分布 / 不可重建数量。

## 测试（9 例新增，tradectl 累计 113 例全绿）

零 venue 写（假 venue 计数为 0）、卡片五要素与限额归属、风控挡下记 riskGate、限额顺序固定、正常卡片可重建、超龄卡片标不可重建且叙述计数、重建输入不一致暴露 limit mismatch、卡片落 journal、状态叙述三要素。真 node:sqlite + 注入时钟，无 mock 无 sleep。

## 本轮的一处纪律失误（记下来，不藏）

提交 `4456214` 是在 shadow 测试**仍然红**的情况下发生的：我把"跑测试 + 门禁 + 提交"串在一条 `&&` 链里，而中间的 `pnpm test | grep …` 因为 grep 命中而返回 0，链没有断。紧接着的 `fc77ea6` 把两处问题修掉（限额输入在卡片与重建之间不一致、断言里限额名大小写写错），并在**验证 113 例全绿之后**才提交。教训：提交前必须自己判测试的**语义**（看输出里的 Tests N passed 那一行），不能依赖管道的退出码。


## 首批跑批报告（2026-10-01，**合成行情**，确定性）

跑法：`node packages/tradectl/drill/shadow-run.ts`（脚本随包提交，可重复执行）。行情是确定性正弦+漂移（不用随机数：随机跑批不可复现就无法当报告），先过 alignment 状态机再进 shadow 装置。

    # shadow 首批跑批（合成行情，确定性）
    - 标的：BTC/USDT；bar 数：120（每 1000ms 一根，共 120s 合成时间）
    - 决策点：每 10 根一次 ⇒ 决策 12 次；其中 open 9、blocked 0、其余 hold
    - 状态叙述：12 decision(s), 0 blocked | blocked by: nothing | cards with stale price
      provenance (not rebuildable): 0 | venue writes: 0 (this desk has no order port at all)
    - 可重建：12/12；重建结论一致：12/12
    - 末态风控：level=normal，闸门判定：{"allowed":true,"reason":"desk level normal and BTC/USDT is aligned"}
    - 审计：journal 行数 12；venue 写次数 0（装置无下单端口）

**跑批过程中发现并修掉的一处配置问题（如实记录）**：第一版给合成行情的快照节奏是**每 30 秒一次**，而年龄预算是 **5 秒** ⇒ 12 张卡片里 **8 张被标成"价格超龄、不可重建"**。这不是装置的缺陷——它恰恰证明年龄预算在起作用；问题在我给的行情节奏与预算不匹配。把快照改成每 2 根一次（贴近真实推流的更新频率）后，12/12 可重建。**两次数字都留在这里**：只留"修好之后"的那组，就看不出这条判据真的会红。

**这份报告的边界（不许含糊）**：

- 行情是**合成的**，不是真实市场；因此它证明的是"装置可跑 + provenance 可重建 + 零 venue 写"，**不构成任何策略有效性证据**。
- 12 次决策里 blocked = 0：合成策略的名义额（约 3k）从未越过 `notionalMax`(10k)。限额路径由单元测试覆盖（`notionalMax` / `positionNotionalMax` / `riskGate` 各有用例），报告里如实写 0，不为了好看去调参数。
- 上界参数用的是示例值（`snapshotAgeBudgetMs: 5000` 等）；**真实部署必须用真实行情在 harness 上重标**，这一点与步骤 4 的结论一致。
- ≥3 天连续观察期**未开始**：按卡片要求写成人工跟进项（观察窗口 ≥72h、看板指标：可重建率、命中限额分布、被风控挡下次数、行情对齐时间占比、venue 写次数必须恒为 0）。


## 真实行情跑批（2026-10-01 同日补完，替代"只有合成行情"的那版）

跑法：`node packages/tradectl/drill/shadow-live.ts 40`（真实 Binance aggTrade 公共流，无凭据、不下单）。

    行情：Binance aggTrade（公共流）· 传输：{"connects":1,"messages":72,"badFrames":0,"state":"live"}
    对齐态：{"epoch":1,"alignment":"aligned","buffered":0,"droppedTicks":0}
    价格样本：[83722.01, 83718, 83718, 83718.01, 83718.01, 83718, 83718.01]
    决策 7 次（open 0）；可重建 7/7；结论一致 7/7
    状态叙述：7 decision(s), 0 blocked | stale provenance: 0 | venue writes: 0

**真实数据又抓出一个集成 bug**：适配器出口给的是交易所写法 `BTCUSDT`，而 REST 快照按内部写法 `BTC/USDT` 查 —— 同一条链路里两种符号写法，导致"按标的"的状态各认各的（第一次跑批决策数为 0，因为决策侧匹配不到任何已发布 tick）。修法：`binanceSymbolToInternal()` 作为**唯一转换点**，出口一律归一。这类 bug 离线测不出来，因为离线测试里两边都是我写的同一种写法。

**这次跑批证明了什么、没证明什么**：证明了"真实行情 → 对齐 → 决策 → 可重建审计 → 零 venue 写"这条链在真实数据上跑得通；**没有**证明任何策略有效性（40 秒、7 次决策、`open 0`——阈值未被触发，样本量与观察窗口都远不够）。≥3 天观察期仍是人工跟进项。

## 未验证项（如实标注）

- **首批报告尚未生成**：卡片交付"装置 + 首批报告"，本轮只有装置；报告要用真实或合成行情喂进 `decide` 才有意义。
- **与真实 agent 决策链路的接线未做**：`thesis` / `action` 目前由调用方给，agent 产出这两个字段的那一段（含 followup 接线）未做。
- **≥3 天连续观察期**按卡片要求写人工跟进项，不在卡内阻塞等待。
- shadow 与 paper 的边界（paper 需要模拟成交）本轮未涉及：装置只做"决策 + 记录"，不模拟撮合。

## 被否决的方案

- **把 venue 端口传进来但约定不调用**：约定挡不住重构；结构上不给才是保证。
- **卡片不记限额归属**：事后无法回答"这单被哪条额度挡下的"，审计就退化成叙述。
- **超龄卡片照常标记为可重建**：那会让"可重建"这个断言失去意义。

**2026-10-02 额度上限成为可执行判据**：限额比较的唯一家仍是 shadow.ts 的 firstLimitHit（顺序不变），上限的值的唯一家是 mandate 的 5 个 upper 字段（SCOPE_FIELDS）。新增三件：MANDATE_LIMIT_FIELDS（由 SCOPE_FIELDS 的 upper 派生，不是第二张表）、resolveMandateLimits()（声明完整性 fail-closed 前置）、openRiskWithinMandate()（有效期 ∧ 声明完整 ∧ 未超的合取，内部直接调用 firstLimitHit，一行比较都没复制）。**缺省语义**：字段缺席 / Infinity / NaN / 负数 / 非数字 ⇒ declared:false ⇒ 拒绝开新仓，code=no-declared-limit（Infinity 明确当无限挡掉）；0 是合法声明（拒绝任何正数新增，code=notionalMax）；判定输入 NaN/负数 ⇒ code=invalid-input（否则比较恒假=静默放行）；到期 ⇒ mandate-not-active。**只约束新增风险**：reduce/hold 在解析上限之前放行。**单位口径**：notionalMax / positionNotionalMax / deskNotionalMax = quote-currency（与 notional = quantity × price 同口径），maxOpenOrders = count，leverageMax = multiple；不做汇率换算，跨币种须在 mandate 层统一后传入。**未接线**：目前唯一消费 limits 的是 shadow 装置（drill 里硬编码）；L0 下单路径出现时必须改用 resolveMandateLimits(mandate) 或直接调 openRiskWithinMandate。
